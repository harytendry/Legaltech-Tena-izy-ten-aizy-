INSERT INTO conditions_societes (nb_min_associes, nb_max_associes, condition_texte , capital_min)
VALUES
(1, 1, 'Peut être constituée par une seule personne physique ou morale', 200000.00), 
(2, 50, 'Deux associés minimum, responsabilité limitée aux apports', 1000000.00),   
(7, NULL, 'Sept actionnaires minimum, société ouverte au public', 10000000.00),    
(2, NULL, 'Deux associés au minimum, responsabilité indéfinie et solidaire', NULL),  
(2, NULL, 'Deux associés au minimum dont au moins un commandité et un commanditaire', 500000.00), 
(1, NULL, 'Un entrepreneur individuel, capital libre, mais responsabilité illimitée', 0.00); 


INSERT INTO types_societe (nom, description, conditions_societes_id)
VALUES
('Entreprise Individuelle (EI)', 'Structure simple, non dotée de la personnalité morale, convenant aux petits entrepreneurs', 6),
('Entreprise Individuelle à Responsabilité Limitée (EIRL)', 'Permet à l''entrepreneur de séparer son patrimoine personnel et professionnel', 1),
('Société à Responsabilité Limitée (SARL)', 'Société adaptée aux PME, souple et sécurisée, responsabilité limitée aux apports', 2),
('Société Anonyme (SA)', 'Société de capitaux, souvent utilisée pour les grandes entreprises ou cotées en bourse', 3),
('Société en Nom Collectif (SNC)', 'Tous les associés sont responsables indéfiniment et solidairement des dettes sociales', 4),
('Société en Commandite Simple (SCS)', 'Comporte des associés commandités (responsables) et des commanditaires (investisseurs)', 5);



INSERT INTO role_actionnaires (nom_role_actionnaires)
VALUES
('Fondateur'),                 
('Associé minoritaire'),       
('Associé majoritaire'),       
('Commandité'),                
('Commanditaire'),             
('Président du Conseil'),      
('Administrateur'),            
('Actionnaire institutionnel'),
('Actionnaire individuel'),    
('Investisseur étranger');     

INSERT INTO type_apports (nom)
VALUES
('Argent'),  
('Autre');    

INSERT INTO categorie_recettes (nom_categorie_recettes)
VALUES
('Vente de produits finis'),
('Prestation de services'),
('Subvention ou aide publique'),
('Investissement ou participation'),
('Location de biens'),
('Intérêts et produits financiers'),
('Autres recettes exceptionnelles');

INSERT INTO categorie_depenses (nom_categorie_depenses)
VALUES
('Achat de matières premières'),
('Salaires et charges sociales'),
('Frais de transport et logistique'),
('Loyer et charges locatives'),
('Fournitures de bureau'),
('Frais de communication'),
('Maintenance et réparations'),
('Marketing et publicité'),
('Énergie et eau'),
('Impôts et taxes'),
('Services externes'),
('Autres charges exceptionnelles');

INSERT INTO type_reunions (nom_reunion)
VALUES
('Assemblée Générale Ordinaire'),
('Réunion du Conseil d''Administration'),
('Réunion de production'),
('Réunion financière'),
('Réunion du personnel'),
('Réunion commerciale'),
('Réunion de projet'),
('Réunion stratégique'),
('Réunion de crise'),
('Réunion de suivi hebdomadaire');


INSERT INTO choix_des_convention (nom)
VALUES
('Tous les employés'),
('Direction uniquement'),
('Chefs de service uniquement'),
('Actionnaires uniquement'),
('Représentants du personnel uniquement'),
('Comité de gestion'),
('Invités externes et direction'),
('Employés permanents uniquement'),
('Employés temporaires et saisonniers'),
('Tout le personnel et partenaires');



INSERT INTO types_convention (nom)
VALUES
('Convention commerciale'),
('Convention interne'),
('Convention financière'),
('Convention de partenariat'),
('Conventions spécifiques'),
('Convention de collaboration'),
('Convention de stage'),
('Convention de recherche'),
('Convention de sous-traitance'),
('Convention d assistance technique'),
('Convention de formation'),
('Convention de prestation de services'),
('Convention d échange universitaire'),
('Convention de coopération internationale');



INSERT INTO lois (numero_loi, intitule, categorie, date_promulgation, resume, conditions, source, type_convention_id) VALUES
('LOI-669/2000', 'Loi relative a la convention commerciale n°29', 'Technologie', '2014-09-23', 'Cette loi fixe les regles du commerce et protege les acteurs economiques.', 'Les entreprises doivent respecter les regles de concurrence et les obligations contractuelles.', 'Journal Officiel de Madagascar - 2014', 1),
('LOI-418/2010', 'Loi relative a la convention commerciale n°15', 'Administration', '2013-06-07', 'Cette loi fixe les regles du commerce et protege les acteurs economiques.', 'Les entreprises doivent respecter les regles de concurrence et les obligations contractuelles.', 'Journal Officiel de Madagascar - 2018', 1),
('LOI-673/2015', 'Loi relative a la convention commerciale n°40', 'Sante', '2010-07-27', 'Cette loi fixe les regles du commerce et protege les acteurs economiques.', 'Les entreprises doivent respecter les regles de concurrence et les obligations contractuelles.', 'Journal Officiel de Madagascar - 2023', 1),
('LOI-882/2023', 'Loi relative a la convention commerciale n°18', 'Travail', '2008-02-05', 'Cette loi fixe les regles du commerce et protege les acteurs economiques.', 'Les entreprises doivent respecter les regles de concurrence et les obligations contractuelles.', 'Journal Officiel de Madagascar - 2012', 1),
('LOI-571/2010', 'Loi relative a la convention commerciale n°41', 'Administration', '2002-01-24', 'Cette loi fixe les regles du commerce et protege les acteurs economiques.', 'Les entreprises doivent respecter les regles de concurrence et les obligations contractuelles.', 'Journal Officiel de Madagascar - 2010', 1),
('LOI-354/2001', 'Loi relative a la convention commerciale n°33', 'Technologie', '2005-10-31', 'Cette loi fixe les regles du commerce et protege les acteurs economiques.', 'Les entreprises doivent respecter les regles de concurrence et les obligations contractuelles.', 'Journal Officiel de Madagascar - 2024', 1),
('LOI-504/2011', 'Loi relative a la convention commerciale n°49', 'Sante', '2025-12-04', 'Cette loi fixe les regles du commerce et protege les acteurs economiques.', 'Les entreprises doivent respecter les regles de concurrence et les obligations contractuelles.', 'Journal Officiel de Madagascar - 2011', 1),
('LOI-350/2009', 'Loi relative a la convention commerciale n°9', 'education', '2024-05-12', 'Cette loi fixe les regles du commerce et protege les acteurs economiques.', 'Les entreprises doivent respecter les regles de concurrence et les obligations contractuelles.', 'Journal Officiel de Madagascar - 2025', 1),
('LOI-315/2001', 'Loi relative a la convention commerciale n°47', 'Travail', '2005-06-19', 'Cette loi fixe les regles du commerce et protege les acteurs economiques.', 'Les entreprises doivent respecter les regles de concurrence et les obligations contractuelles.', 'Journal Officiel de Madagascar - 2022', 1),
('LOI-458/2012', 'Loi relative a la convention interne n°1', 'Industrie', '2019-02-09', 'Cette loi regit la gestion interne et le fonctionnement administratif des institutions.', 'Les procedures internes doivent etre validees par les autorites de controle.', 'Journal Officiel de Madagascar - 2013', 2),

('LOI-290/2020', 'Loi relative a la convention interne n°29', 'Travail', '2012-01-19', 'Cette loi regit la gestion interne et le fonctionnement administratif des institutions.', 'Les procedures internes doivent etre validees par les autorites de controle.', 'Journal Officiel de Madagascar - 2010', 2),
('LOI-894/2024', 'Loi relative a la convention interne n°30', 'Technologie', '2008-03-10', 'Cette loi regit la gestion interne et le fonctionnement administratif des institutions.', 'Les procedures internes doivent etre validees par les autorites de controle.', 'Journal Officiel de Madagascar - 2018', 2),
('LOI-245/2025', 'Loi relative a la convention interne n°7', 'education', '2012-11-22', 'Cette loi regit la gestion interne et le fonctionnement administratif des institutions.', 'Les procedures internes doivent etre validees par les autorites de controle.', 'Journal Officiel de Madagascar - 2014', 2),
('LOI-334/2003', 'Loi relative a la convention interne n°31', 'Technologie', '2024-12-22', 'Cette loi regit la gestion interne et le fonctionnement administratif des institutions.', 'Les procedures internes doivent etre validees par les autorites de controle.', 'Journal Officiel de Madagascar - 2017', 2),
('LOI-332/2024', 'Loi relative a la convention interne n°7', 'Technologie', '2011-03-29', 'Cette loi regit la gestion interne et le fonctionnement administratif des institutions.', 'Les procedures internes doivent etre validees par les autorites de controle.', 'Journal Officiel de Madagascar - 2023', 2),
('LOI-533/2014', 'Loi relative a la convention interne n°30', 'education', '2020-02-13', 'Cette loi regit la gestion interne et le fonctionnement administratif des institutions.', 'Les procedures internes doivent etre validees par les autorites de controle.', 'Journal Officiel de Madagascar - 2015', 2),
('LOI-785/2005', 'Loi relative a la convention interne n°7', 'Industrie', '2011-02-14', 'Cette loi regit la gestion interne et le fonctionnement administratif des institutions.', 'Les procedures internes doivent etre validees par les autorites de controle.', 'Journal Officiel de Madagascar - 2011', 2),
('LOI-270/2009', 'Loi relative a la convention interne n°48', 'education', '2025-01-08', 'Cette loi regit la gestion interne et le fonctionnement administratif des institutions.', 'Les procedures internes doivent etre validees par les autorites de controle.', 'Journal Officiel de Madagascar - 2010', 2),
('LOI-714/2020', 'Loi relative a la convention financiere n°5', 'Industrie', '2007-11-04', 'Cette loi regule les flux financiers publics et prives pour assurer la transparence.', 'Les rapports financiers doivent etre publies et controles par les institutions competentes.', 'Journal Officiel de Madagascar - 2021', 3),
('LOI-539/2004', 'Loi relative a la convention financiere n°48', 'Industrie', '2000-09-24', 'Cette loi regule les flux financiers publics et prives pour assurer la transparence.', 'Les rapports financiers doivent etre publies et controles par les institutions competentes.', 'Journal Officiel de Madagascar - 2017', 3),
('LOI-579/2001', 'Loi relative a la convention financiere n°47', 'Administration', '2003-06-22', 'Cette loi regule les flux financiers publics et prives pour assurer la transparence.', 'Les rapports financiers doivent etre publies et controles par les institutions competentes.', 'Journal Officiel de Madagascar - 2019', 3),
('LOI-361/2018', 'Loi relative a la convention financiere n°46', 'education', '2023-09-01', 'Cette loi regule les flux financiers publics et prives pour assurer la transparence.', 'Les rapports financiers doivent etre publies et controles par les institutions competentes.', 'Journal Officiel de Madagascar - 2023', 3),
('LOI-946/2014', 'Loi relative a la convention financiere n°24', 'economie', '2021-04-17', 'Cette loi regule les flux financiers publics et prives pour assurer la transparence.', 'Les rapports financiers doivent etre publies et controles par les institutions competentes.', 'Journal Officiel de Madagascar - 2013', 3),
('LOI-405/2000', 'Loi relative a la convention financiere n°22', 'Travail', '2012-01-09', 'Cette loi regule les flux financiers publics et prives pour assurer la transparence.', 'Les rapports financiers doivent etre publies et controles par les institutions competentes.', 'Journal Officiel de Madagascar - 2019', 3),
('LOI-388/2002', 'Loi relative a la convention financiere n°43', 'Travail', '2019-05-27', 'Cette loi regule les flux financiers publics et prives pour assurer la transparence.', 'Les rapports financiers doivent etre publies et controles par les institutions competentes.', 'Journal Officiel de Madagascar - 2025', 3),
('LOI-559/2011', 'Loi relative a la convention financiere n°8', 'Industrie', '2015-09-03', 'Cette loi regule les flux financiers publics et prives pour assurer la transparence.', 'Les rapports financiers doivent etre publies et controles par les institutions competentes.', 'Journal Officiel de Madagascar - 2024', 3),
('LOI-873/2019', 'Loi relative a la convention financiere n°35', 'economie', '2008-12-27', 'Cette loi regule les flux financiers publics et prives pour assurer la transparence.', 'Les rapports financiers doivent etre publies et controles par les institutions competentes.', 'Journal Officiel de Madagascar - 2022', 3),
('LOI-852/2003', 'Loi relative a la convention financiere n°11', 'education', '2018-11-15', 'Cette loi regule les flux financiers publics et prives pour assurer la transparence.', 'Les rapports financiers doivent etre publies et controles par les institutions competentes.', 'Journal Officiel de Madagascar - 2014', 3),
('LOI-376/2012', 'Loi relative a la convention de partenariat n°9', 'Sante', '2008-12-22', 'Cette loi encadre les partenariats entre secteurs public et prive.', 'Tout partenariat doit faire l objet d un contrat clair et d un suivi regulier.', 'Journal Officiel de Madagascar - 2018', 4),
('LOI-210/2022', 'Loi relative a la convention de partenariat n°23', 'Industrie', '2008-10-13', 'Cette loi encadre les partenariats entre secteurs public et prive.', 'Tout partenariat doit faire l objet d un contrat clair et d un suivi regulier.', 'Journal Officiel de Madagascar - 2016', 4),
('LOI-652/2018', 'Loi relative a la convention de partenariat n°36', 'Technologie', '2022-09-09', 'Cette loi encadre les partenariats entre secteurs public et prive.', 'Tout partenariat doit faire l objet d un contrat clair et d un suivi regulier.', 'Journal Officiel de Madagascar - 2019', 4),
('LOI-298/2008', 'Loi relative a la convention de partenariat n°42', 'Technologie', '2006-11-01', 'Cette loi encadre les partenariats entre secteurs public et prive.', 'Tout partenariat doit faire l objet d un contrat clair et d un suivi regulier.', 'Journal Officiel de Madagascar - 2013', 4),
('LOI-795/2002', 'Loi relative a la convention de partenariat n°50', 'Sante', '2020-11-07', 'Cette loi encadre les partenariats entre secteurs public et prive.', 'Tout partenariat doit faire l objet d un contrat clair et d un suivi regulier.', 'Journal Officiel de Madagascar - 2023', 4),
('LOI-700/2002', 'Loi relative a la convention de partenariat n°35', 'Sante', '2014-01-13', 'Cette loi encadre les partenariats entre secteurs public et prive.', 'Tout partenariat doit faire l objet d un contrat clair et d un suivi regulier.', 'Journal Officiel de Madagascar - 2021', 4),
('LOI-849/2023', 'Loi relative a la convention de partenariat n°16', 'education', '2015-06-27', 'Cette loi encadre les partenariats entre secteurs public et prive.', 'Tout partenariat doit faire l objet d un contrat clair et d un suivi regulier.', 'Journal Officiel de Madagascar - 2023', 4),
('LOI-574/2012', 'Loi relative a la convention de partenariat n°5', 'Sante', '2021-08-10', 'Cette loi encadre les partenariats entre secteurs public et prive.', 'Tout partenariat doit faire l objet d un contrat clair et d un suivi regulier.', 'Journal Officiel de Madagascar - 2011', 4),
('LOI-591/2013', 'Loi relative a la convention de partenariat n°38', 'Sante', '2005-08-04', 'Cette loi encadre les partenariats entre secteurs public et prive.', 'Tout partenariat doit faire l objet d un contrat clair et d un suivi regulier.', 'Journal Officiel de Madagascar - 2025', 4),
('LOI-356/2007', 'Loi relative a la conventions specifiques n°2', 'Industrie', '2000-01-05', 'Cette loi definit les conventions specifiques applicables a certains projets cibles.', 'Les clauses techniques et juridiques doivent etre approuvees avant execution.', 'Journal Officiel de Madagascar - 2012', 5),
('LOI-538/2007', 'Loi relative a la conventions specifiques n°3', 'Administration', '2021-06-27', 'Cette loi definit les conventions specifiques applicables a certains projets cibles.', 'Les clauses techniques et juridiques doivent etre approuvees avant execution.', 'Journal Officiel de Madagascar - 2019', 5),
('LOI-733/2000', 'Loi relative a la conventions specifiques n°17', 'Travail', '2010-04-09', 'Cette loi definit les conventions specifiques applicables a certains projets cibles.', 'Les clauses techniques et juridiques doivent etre approuvees avant execution.', 'Journal Officiel de Madagascar - 2012', 5),
('LOI-430/2019', 'Loi relative a la conventions specifiques n°2', 'economie', '2001-12-14', 'Cette loi definit les conventions specifiques applicables a certains projets cibles.', 'Les clauses techniques et juridiques doivent etre approuvees avant execution.', 'Journal Officiel de Madagascar - 2021', 5),
('LOI-358/2020', 'Loi relative a la conventions specifiques n°46', 'economie', '2024-12-01', 'Cette loi definit les conventions specifiques applicables a certains projets cibles.', 'Les clauses techniques et juridiques doivent etre approuvees avant execution.', 'Journal Officiel de Madagascar - 2010', 5),
('LOI-765/2017', 'Loi relative a la conventions specifiques n°27', 'Travail', '2001-12-11', 'Cette loi definit les conventions specifiques applicables a certains projets cibles.', 'Les clauses techniques et juridiques doivent etre approuvees avant execution.', 'Journal Officiel de Madagascar - 2014', 5),
('LOI-694/2009', 'Loi relative a la conventions specifiques n°1', 'education', '2003-04-26', 'Cette loi definit les conventions specifiques applicables a certains projets cibles.', 'Les clauses techniques et juridiques doivent etre approuvees avant execution.', 'Journal Officiel de Madagascar - 2019', 5),
('LOI-486/2013', 'Loi relative a la convention de collaboration n°38', 'education', '2012-02-29', 'Cette loi organise la collaboration entre institutions pour renforcer la coordination nationale.', 'Les conventions doivent etre soumises a l approbation des organes de tutelle.', 'Journal Officiel de Madagascar - 2017', 6),
('LOI-877/2006', 'Loi relative a la convention de collaboration n°3', 'education', '2017-11-10', 'Cette loi organise la collaboration entre institutions pour renforcer la coordination nationale.', 'Les conventions doivent etre soumises a l approbation des organes de tutelle.', 'Journal Officiel de Madagascar - 2013', 6),
('LOI-932/2024', 'Loi relative a la convention de collaboration n°25', 'Industrie', '2012-03-26', 'Cette loi organise la collaboration entre institutions pour renforcer la coordination nationale.', 'Les conventions doivent etre soumises a l approbation des organes de tutelle.', 'Journal Officiel de Madagascar - 2010', 6),
('LOI-230/2024', 'Loi relative a la convention de collaboration n°47', 'Administration', '2023-01-08', 'Cette loi organise la collaboration entre institutions pour renforcer la coordination nationale.', 'Les conventions doivent etre soumises a l approbation des organes de tutelle.', 'Journal Officiel de Madagascar - 2012', 6),
('LOI-901/2024', 'Loi relative a la convention de collaboration n°27', 'Administration', '2022-12-31', 'Cette loi organise la collaboration entre institutions pour renforcer la coordination nationale.', 'Les conventions doivent etre soumises a l approbation des organes de tutelle.', 'Journal Officiel de Madagascar - 2014', 6),
('LOI-652/2001', 'Loi relative a la convention de collaboration n°14', 'economie', '2011-08-07', 'Cette loi organise la collaboration entre institutions pour renforcer la coordination nationale.', 'Les conventions doivent etre soumises a l approbation des organes de tutelle.', 'Journal Officiel de Madagascar - 2015', 6),
('LOI-598/2020', 'Loi relative a la convention de collaboration n°31', 'economie', '2002-12-12', 'Cette loi organise la collaboration entre institutions pour renforcer la coordination nationale.', 'Les conventions doivent etre soumises a l approbation des organes de tutelle.', 'Journal Officiel de Madagascar - 2011', 6),
('LOI-276/2017', 'Loi relative a la convention de collaboration n°32', 'Administration', '2013-08-30', 'Cette loi organise la collaboration entre institutions pour renforcer la coordination nationale.', 'Les conventions doivent etre soumises a l approbation des organes de tutelle.', 'Journal Officiel de Madagascar - 2025', 6),
('LOI-260/2011', 'Loi relative a la convention de stage n°49', 'Travail', '2021-12-11', 'Cette loi encadre les stages pour promouvoir l insertion professionnelle des jeunes.', 'Les employeurs doivent garantir un environnement de formation conforme aux normes.', 'Journal Officiel de Madagascar - 2011', 7),
('LOI-683/2020', 'Loi relative a la convention de stage n°41', 'Technologie', '2004-12-09', 'Cette loi encadre les stages pour promouvoir l insertion professionnelle des jeunes.', 'Les employeurs doivent garantir un environnement de formation conforme aux normes.', 'Journal Officiel de Madagascar - 2022', 7),
('LOI-143/2025', 'Loi relative a la convention de stage n°30', 'Administration', '2002-08-28', 'Cette loi encadre les stages pour promouvoir l insertion professionnelle des jeunes.', 'Les employeurs doivent garantir un environnement de formation conforme aux normes.', 'Journal Officiel de Madagascar - 2010', 7),
('LOI-922/2013', 'Loi relative a la convention de stage n°34', 'education', '2013-04-08', 'Cette loi encadre les stages pour promouvoir l insertion professionnelle des jeunes.', 'Les employeurs doivent garantir un environnement de formation conforme aux normes.', 'Journal Officiel de Madagascar - 2018', 7),
('LOI-644/2004', 'Loi relative a la convention de stage n°46', 'Industrie', '2015-09-16', 'Cette loi encadre les stages pour promouvoir l insertion professionnelle des jeunes.', 'Les employeurs doivent garantir un environnement de formation conforme aux normes.', 'Journal Officiel de Madagascar - 2020', 7),
('LOI-671/2017', 'Loi relative a la convention de stage n°31', 'Administration', '2023-06-03', 'Cette loi encadre les stages pour promouvoir l insertion professionnelle des jeunes.', 'Les employeurs doivent garantir un environnement de formation conforme aux normes.', 'Journal Officiel de Madagascar - 2021', 7),
('LOI-742/2018', 'Loi relative a la convention de stage n°37', 'economie', '2014-08-04', 'Cette loi encadre les stages pour promouvoir l insertion professionnelle des jeunes.', 'Les employeurs doivent garantir un environnement de formation conforme aux normes.', 'Journal Officiel de Madagascar - 2019', 7),
('LOI-518/2009', 'Loi relative a la convention de recherche n°20', 'Technologie', '2009-09-07', 'Cette loi favorise la recherche et l innovation scientifique.', 'Les resultats de recherche doivent etre proteges et partages de maniere equitable.', 'Journal Officiel de Madagascar - 2021', 8),
('LOI-532/2003', 'Loi relative a la convention de recherche n°5', 'Travail', '2025-01-15', 'Cette loi favorise la recherche et l innovation scientifique.', 'Les resultats de recherche doivent etre proteges et partages de maniere equitable.', 'Journal Officiel de Madagascar - 2016', 8),
('LOI-449/2020', 'Loi relative a la convention de recherche n°46', 'Industrie', '2019-09-10', 'Cette loi favorise la recherche et l innovation scientifique.', 'Les resultats de recherche doivent etre proteges et partages de maniere equitable.', 'Journal Officiel de Madagascar - 2012', 8),
('LOI-687/2013', 'Loi relative a la convention de recherche n°32', 'Technologie', '2012-10-31', 'Cette loi favorise la recherche et l innovation scientifique.', 'Les resultats de recherche doivent etre proteges et partages de maniere equitable.', 'Journal Officiel de Madagascar - 2024', 8),
('LOI-924/2011', 'Loi relative a la convention de recherche n°41', 'economie', '2008-10-16', 'Cette loi favorise la recherche et l innovation scientifique.', 'Les resultats de recherche doivent etre proteges et partages de maniere equitable.', 'Journal Officiel de Madagascar - 2016', 8),
('LOI-842/2022', 'Loi relative a la convention de recherche n°28', 'economie', '2017-09-20', 'Cette loi favorise la recherche et l innovation scientifique.', 'Les resultats de recherche doivent etre proteges et partages de maniere equitable.', 'Journal Officiel de Madagascar - 2011', 8),
('LOI-431/2021', 'Loi relative a la convention de recherche n°33', 'education', '2007-11-20', 'Cette loi favorise la recherche et l innovation scientifique.', 'Les resultats de recherche doivent etre proteges et partages de maniere equitable.', 'Journal Officiel de Madagascar - 2019', 8),
('LOI-594/2000', 'Loi relative a la convention de sous-traitance n°32', 'Travail', '2005-08-06', 'Cette loi fixe les regles relatives a la sous traitance des activites economiques.', 'Les contrats de sous traitance doivent definir clairement les responsabilites des parties.', 'Journal Officiel de Madagascar - 2023', 9),
('LOI-459/2009', 'Loi relative a la convention de sous-traitance n°7', 'education', '2025-12-13', 'Cette loi fixe les regles relatives a la sous traitance des activites economiques.', 'Les contrats de sous traitance doivent definir clairement les responsabilites des parties.', 'Journal Officiel de Madagascar - 2015', 9),
('LOI-202/2008', 'Loi relative a la convention de sous-traitance n°16', 'education', '2003-05-16', 'Cette loi fixe les regles relatives a la sous traitance des activites economiques.', 'Les contrats de sous traitance doivent definir clairement les responsabilites des parties.', 'Journal Officiel de Madagascar - 2020', 9),
('LOI-640/2013', 'Loi relative a la convention de sous-traitance n°2', 'Industrie', '2021-10-30', 'Cette loi fixe les regles relatives a la sous traitance des activites economiques.', 'Les contrats de sous traitance doivent definir clairement les responsabilites des parties.', 'Journal Officiel de Madagascar - 2010', 9),
('LOI-640/2016', 'Loi relative a la convention de sous-traitance n°34', 'education', '2002-01-16', 'Cette loi fixe les regles relatives a la sous traitance des activites economiques.', 'Les contrats de sous traitance doivent definir clairement les responsabilites des parties.', 'Journal Officiel de Madagascar - 2018', 9),
('LOI-372/2021', 'Loi relative a la convention de sous-traitance n°6', 'Industrie', '2021-01-18', 'Cette loi fixe les regles relatives a la sous traitance des activites economiques.', 'Les contrats de sous traitance doivent definir clairement les responsabilites des parties.', 'Journal Officiel de Madagascar - 2019', 9),
('LOI-555/2025', 'Loi relative a la convention de sous-traitance n°16', 'Travail', '2013-04-29', 'Cette loi fixe les regles relatives a la sous traitance des activites economiques.', 'Les contrats de sous traitance doivent definir clairement les responsabilites des parties.', 'Journal Officiel de Madagascar - 2019', 9),
('LOI-566/2014', 'Loi relative a la convention d assistance technique n°16', 'Sante', '2019-04-25', 'Cette loi regit l assistance technique visant a renforcer les competences locales.', 'Les missions techniques doivent etre validees et documentees par un rapport final.', 'Journal Officiel de Madagascar - 2019', 10),
('LOI-437/2024', 'Loi relative a la convention d assistance technique n°29', 'Industrie', '2015-01-22', 'Cette loi regit l assistance technique visant a renforcer les competences locales.', 'Les missions techniques doivent etre validees et documentees par un rapport final.', 'Journal Officiel de Madagascar - 2020', 10),
('LOI-388/2004', 'Loi relative a la convention d assistance technique n°3', 'education', '2025-09-09', 'Cette loi regit l assistance technique visant a renforcer les competences locales.', 'Les missions techniques doivent etre validees et documentees par un rapport final.', 'Journal Officiel de Madagascar - 2021', 10),
('LOI-333/2006', 'Loi relative a la convention d assistance technique n°38', 'Administration', '2017-01-17', 'Cette loi regit l assistance technique visant a renforcer les competences locales.', 'Les missions techniques doivent etre validees et documentees par un rapport final.', 'Journal Officiel de Madagascar - 2013', 10),
('LOI-488/2001', 'Loi relative a la convention d assistance technique n°29', 'Administration', '2014-03-30', 'Cette loi regit l assistance technique visant a renforcer les competences locales.', 'Les missions techniques doivent etre validees et documentees par un rapport final.', 'Journal Officiel de Madagascar - 2014', 10),
('LOI-659/2025', 'Loi relative a la convention d assistance technique n°15', 'Sante', '2009-08-29', 'Cette loi regit l assistance technique visant a renforcer les competences locales.', 'Les missions techniques doivent etre validees et documentees par un rapport final.', 'Journal Officiel de Madagascar - 2013', 10),
('LOI-158/2014', 'Loi relative a la convention d assistance technique n°38', 'Travail', '2009-09-03', 'Cette loi regit l assistance technique visant a renforcer les competences locales.', 'Les missions techniques doivent etre validees et documentees par un rapport final.', 'Journal Officiel de Madagascar - 2012', 10),
('LOI-547/2019', 'Loi relative a la convention d assistance technique n°10', 'economie', '2010-11-14', 'Cette loi regit l assistance technique visant a renforcer les competences locales.', 'Les missions techniques doivent etre validees et documentees par un rapport final.', 'Journal Officiel de Madagascar - 2019', 10),
('LOI-922/2015', 'Loi relative a la convention de formation n°48', 'economie', '2002-10-07', 'Cette loi etablit les bases de la formation professionnelle et continue.', 'Les formations doivent repondre aux besoins identifiees du marche du travail.', 'Journal Officiel de Madagascar - 2016', 11),
('LOI-433/2004', 'Loi relative a la convention de formation n°22', 'economie', '2012-11-17', 'Cette loi etablit les bases de la formation professionnelle et continue.', 'Les formations doivent repondre aux besoins identifiees du marche du travail.', 'Journal Officiel de Madagascar - 2023', 11),
('LOI-893/2013', 'Loi relative a la convention de formation n°50', 'Sante', '2019-01-08', 'Cette loi etablit les bases de la formation professionnelle et continue.', 'Les formations doivent repondre aux besoins identifiees du marche du travail.', 'Journal Officiel de Madagascar - 2023', 11),
('LOI-401/2004', 'Loi relative a la convention de formation n°44', 'education', '2021-10-10', 'Cette loi etablit les bases de la formation professionnelle et continue.', 'Les formations doivent repondre aux besoins identifiees du marche du travail.', 'Journal Officiel de Madagascar - 2015', 11),
('LOI-118/2001', 'Loi relative a la convention de formation n°24', 'Travail', '2025-05-10', 'Cette loi etablit les bases de la formation professionnelle et continue.', 'Les formations doivent repondre aux besoins identifiees du marche du travail.', 'Journal Officiel de Madagascar - 2022', 11),
('LOI-727/2017', 'Loi relative a la convention de formation n°27', 'Administration', '2014-05-27', 'Cette loi etablit les bases de la formation professionnelle et continue.', 'Les formations doivent repondre aux besoins identifiees du marche du travail.', 'Journal Officiel de Madagascar - 2024', 11),
('LOI-471/2017', 'Loi relative a la convention de formation n°14', 'Sante', '2025-05-18', 'Cette loi etablit les bases de la formation professionnelle et continue.', 'Les formations doivent repondre aux besoins identifiees du marche du travail.', 'Journal Officiel de Madagascar - 2012', 11),
('LOI-810/2003', 'Loi relative a la convention de formation n°30', 'Administration', '2002-05-13', 'Cette loi etablit les bases de la formation professionnelle et continue.', 'Les formations doivent repondre aux besoins identifiees du marche du travail.', 'Journal Officiel de Madagascar - 2014', 11),
('LOI-582/2000', 'Loi relative a la convention de formation n°10', 'economie', '2023-07-08', 'Cette loi etablit les bases de la formation professionnelle et continue.', 'Les formations doivent repondre aux besoins identifiees du marche du travail.', 'Journal Officiel de Madagascar - 2015', 11),
('LOI-775/2025', 'Loi relative a la convention de prestation de services n°42', 'education', '2013-02-28', 'Cette loi encadre les prestations de services entre acteurs prives et publics.', 'Les prestataires doivent executer leurs engagements dans les delais convenus.', 'Journal Officiel de Madagascar - 2022', 12),
('LOI-475/2019', 'Loi relative a la convention de prestation de services n°47', 'Sante', '2009-04-22', 'Cette loi encadre les prestations de services entre acteurs prives et publics.', 'Les prestataires doivent executer leurs engagements dans les delais convenus.', 'Journal Officiel de Madagascar - 2021', 12),
('LOI-833/2000', 'Loi relative a la convention de prestation de services n°9', 'Industrie', '2002-02-06', 'Cette loi encadre les prestations de services entre acteurs prives et publics.', 'Les prestataires doivent executer leurs engagements dans les delais convenus.', 'Journal Officiel de Madagascar - 2018', 12),
('LOI-773/2024', 'Loi relative a la convention de prestation de services n°30', 'Travail', '2022-12-15', 'Cette loi encadre les prestations de services entre acteurs prives et publics.', 'Les prestataires doivent executer leurs engagements dans les delais convenus.', 'Journal Officiel de Madagascar - 2012', 12),
('LOI-474/2021', 'Loi relative a la convention de prestation de services n°15', 'Sante', '2009-05-17', 'Cette loi encadre les prestations de services entre acteurs prives et publics.', 'Les prestataires doivent executer leurs engagements dans les delais convenus.', 'Journal Officiel de Madagascar - 2014', 12),
('LOI-949/2010', 'Loi relative a la convention de prestation de services n°25', 'Administration', '2012-03-15', 'Cette loi encadre les prestations de services entre acteurs prives et publics.', 'Les prestataires doivent executer leurs engagements dans les delais convenus.', 'Journal Officiel de Madagascar - 2017', 12),
('LOI-928/2001', 'Loi relative a la convention de prestation de services n°19', 'Travail', '2015-05-31', 'Cette loi encadre les prestations de services entre acteurs prives et publics.', 'Les prestataires doivent executer leurs engagements dans les delais convenus.', 'Journal Officiel de Madagascar - 2013', 12),
('LOI-619/2009', 'Loi relative a la convention de prestation de services n°46', 'Travail', '2020-02-04', 'Cette loi encadre les prestations de services entre acteurs prives et publics.', 'Les prestataires doivent executer leurs engagements dans les delais convenus.', 'Journal Officiel de Madagascar - 2013', 12),
('LOI-410/2024', 'Loi relative a la convention d echange universitaire n°7', 'Travail', '2011-06-14', 'Cette loi regit les echanges universitaires et la mobilite academique.', 'Les universites doivent garantir la reconnaissance reciproque des credits.', 'Journal Officiel de Madagascar - 2012', 13),
('LOI-927/2023', 'Loi relative a la convention d echange universitaire n°3', 'Administration', '2015-11-21', 'Cette loi regit les echanges universitaires et la mobilite academique.', 'Les universites doivent garantir la reconnaissance reciproque des credits.', 'Journal Officiel de Madagascar - 2023', 13),
('LOI-721/2023', 'Loi relative a la convention d echange universitaire n°50', 'economie', '2012-07-21', 'Cette loi regit les echanges universitaires et la mobilite academique.', 'Les universites doivent garantir la reconnaissance reciproque des credits.', 'Journal Officiel de Madagascar - 2017', 13),
('LOI-639/2021', 'Loi relative a la convention d echange universitaire n°18', 'Travail', '2012-06-19', 'Cette loi regit les echanges universitaires et la mobilite academique.', 'Les universites doivent garantir la reconnaissance reciproque des credits.', 'Journal Officiel de Madagascar - 2019', 13),
('LOI-689/2018', 'Loi relative a la convention d echange universitaire n°20', 'Administration', '2008-02-27', 'Cette loi regit les echanges universitaires et la mobilite academique.', 'Les universites doivent garantir la reconnaissance reciproque des credits.', 'Journal Officiel de Madagascar - 2012', 13),
('LOI-381/2010', 'Loi relative a la convention d echange universitaire n°12', 'economie', '2006-04-17', 'Cette loi regit les echanges universitaires et la mobilite academique.', 'Les universites doivent garantir la reconnaissance reciproque des credits.', 'Journal Officiel de Madagascar - 2016', 13),
('LOI-323/2007', 'Loi relative a la convention d echange universitaire n°28', 'Sante', '2021-06-01', 'Cette loi regit les echanges universitaires et la mobilite academique.', 'Les universites doivent garantir la reconnaissance reciproque des credits.', 'Journal Officiel de Madagascar - 2016', 13),
('LOI-633/2007', 'Loi relative a la convention de cooperation internationale n°3', 'education', '2010-02-02', 'Cette loi organise la cooperation internationale sur le plan economique et technique.', 'Les accords de cooperation doivent etre ratifies et conformes aux interets nationaux.', 'Journal Officiel de Madagascar - 2019', 14),
('LOI-579/2002', 'Loi relative a la convention de cooperation internationale n°5', 'economie', '2007-07-30', 'Cette loi organise la cooperation internationale sur le plan economique et technique.', 'Les accords de cooperation doivent etre ratifies et conformes aux interets nationaux.', 'Journal Officiel de Madagascar - 2024', 14),
('LOI-939/2012', 'Loi relative a la convention de cooperation internationale n°8', 'Travail', '2015-10-19', 'Cette loi organise la cooperation internationale sur le plan economique et technique.', 'Les accords de cooperation doivent etre ratifies et conformes aux interets nationaux.', 'Journal Officiel de Madagascar - 2013', 14),
('LOI-143/2012', 'Loi relative a la convention de cooperation internationale n°44', 'Sante', '2005-10-30', 'Cette loi organise la cooperation internationale sur le plan economique et technique.', 'Les accords de cooperation doivent etre ratifies et conformes aux interets nationaux.', 'Journal Officiel de Madagascar - 2015', 14),
('LOI-815/2015', 'Loi relative a la convention de cooperation internationale n°14', 'Technologie', '2019-07-17', 'Cette loi organise la cooperation internationale sur le plan economique et technique.', 'Les accords de cooperation doivent etre ratifies et conformes aux interets nationaux.', 'Journal Officiel de Madagascar - 2025', 14),
('LOI-424/2022', 'Loi relative a la convention de cooperation internationale n°1', 'Sante', '2022-09-04', 'Cette loi organise la cooperation internationale sur le plan economique et technique.', 'Les accords de cooperation doivent etre ratifies et conformes aux interets nationaux.', 'Journal Officiel de Madagascar - 2023', 14),
('LOI-111/2007', 'Loi relative a la convention de cooperation internationale n°5', 'Technologie', '2012-04-05', 'Cette loi organise la cooperation internationale sur le plan economique et technique.', 'Les accords de cooperation doivent etre ratifies et conformes aux interets nationaux.', 'Journal Officiel de Madagascar - 2010', 14),
('LOI-320/2004', 'Loi relative a la convention de cooperation internationale n°10', 'education', '2019-03-08', 'Cette loi organise la cooperation internationale sur le plan economique et technique.', 'Les accords de cooperation doivent etre ratifies et conformes aux interets nationaux.', 'Journal Officiel de Madagascar - 2014', 14);



-- Convention commerciale (id = 1)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Nom du client / fournisseur', 1, 'VARCHAR(190)'),
('Nature du service / produit', 1, 'VARCHAR(255)'),
('Montant / prix convenu', 1, 'DECIMAL(50,2)'),
('Conditions de paiement', 1, 'TEXT'),
('Livraison / exécution', 1, 'DATE'),
('Pénalités ou garanties', 1, 'TEXT');

-- Convention interne (id = 2)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Nom de l''associé / dirigeant', 2, 'VARCHAR(190)'),
('Type d''accord interne', 2, 'VARCHAR(190)'),
('Montant concerné', 2, 'DECIMAL(50,2)'),
('Décision autorisante', 2, 'TEXT'),
('Confidentialité', 2, 'BOOLEAN'),
('Durée / modalités de résiliation', 2, 'VARCHAR(190)');

-- Convention financière (id = 3)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Montant du prêt / investissement', 3, 'DECIMAL(50,2)'),
('Taux d''intérêt (si applicable)', 3, 'DECIMAL(50,2)'),
('Durée / échéance', 3, 'VARCHAR(100)'),
('Garanties prévues', 3, 'TEXT'),
('Modalités de remboursement', 3, 'TEXT'),
('Source de financement', 3, 'VARCHAR(190)');

-- Convention de partenariat (id = 4)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Nom du partenaire', 4, 'VARCHAR(190)'),
('Objectif du partenariat', 4, 'TEXT'),
('Rôles et responsabilités', 4, 'TEXT'),
('Répartition des coûts / bénéfices', 4, 'TEXT'),
('Durée de la collaboration', 4, 'VARCHAR(100)'),
('Propriété des résultats', 4, 'TEXT'),
('Modalités de résiliation', 4, 'VARCHAR(190)');

-- Convention spécifique (id = 5)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Objet de la convention', 5, 'TEXT'),
('Cadre juridique applicable', 5, 'VARCHAR(255)'),
('Parties impliquées', 5, 'TEXT'),
('Durée de validité', 5, 'VARCHAR(100)'),
('Budget ou ressources allouées', 5, 'DECIMAL(50,2)'),
('Conditions particulières', 5, 'TEXT');

-- Convention de collaboration (id = 6)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Nom des partenaires', 6, 'TEXT'),
('Objectif commun', 6, 'TEXT'),
('Contribution de chaque partie', 6, 'TEXT'),
('Durée de la collaboration', 6, 'VARCHAR(100)'),
('Modalités de communication', 6, 'TEXT'),
('Suivi et évaluation', 6, 'TEXT');

-- Convention de stage (id = 7)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Nom de l''étudiant', 7, 'VARCHAR(190)'),
('Établissement d''origine', 7, 'VARCHAR(190)'),
('Entreprise ou institution d''accueil', 7, 'VARCHAR(190)'),
('Période du stage', 7, 'DATE'),
('Encadrant / tuteur', 7, 'VARCHAR(190)'),
('Objectif du stage', 7, 'TEXT'),
('Indemnité ou non', 7, 'BOOLEAN');

-- Convention de recherche (id = 8)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Titre du projet', 8, 'VARCHAR(255)'),
('Responsable scientifique', 8, 'VARCHAR(190)'),
('Organisme financeur', 8, 'VARCHAR(190)'),
('Durée du projet', 8, 'VARCHAR(100)'),
('Budget prévu', 8, 'DECIMAL(50,2)'),
('Propriété intellectuelle', 8, 'TEXT'),
('Résultats attendus', 8, 'TEXT');

-- Convention de sous-traitance (id = 9)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Nom du prestataire', 9, 'VARCHAR(190)'),
('Nature des travaux', 9, 'TEXT'),
('Montant total', 9, 'DECIMAL(50,2)'),
('Échéancier de paiement', 9, 'TEXT'),
('Pénalités de retard', 9, 'TEXT'),
('Garanties exigées', 9, 'TEXT'),
('Durée du contrat', 9, 'VARCHAR(100)');

-- Convention d’assistance technique (id = 10)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Fournisseur d''assistance', 10, 'VARCHAR(190)'),
('Objet de l''assistance', 10, 'TEXT'),
('Durée d''intervention', 10, 'VARCHAR(100)'),
('Coût estimatif', 10, 'DECIMAL(50,2)'),
('Résultats attendus', 10, 'TEXT'),
('Modalités de suivi', 10, 'TEXT');

-- Convention de formation (id = 11)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Organisme de formation', 11, 'VARCHAR(190)'),
('Thème de la formation', 11, 'VARCHAR(255)'),
('Durée', 11, 'VARCHAR(100)'),
('Public cible', 11, 'TEXT'),
('Nombre de participants', 11, 'INT'),
('Coût total', 11, 'DECIMAL(50,2)'),
('Modalités d''évaluation', 11, 'TEXT');

-- Convention de prestation de services (id = 12)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Nom du prestataire', 12, 'VARCHAR(190)'),
('Nature de la prestation', 12, 'TEXT'),
('Montant du contrat', 12, 'DECIMAL(50,2)'),
('Durée de la prestation', 12, 'VARCHAR(100)'),
('Conditions de facturation', 12, 'TEXT'),
('Livrables attendus', 12, 'TEXT');

-- Convention d’échange universitaire (id = 13)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Nom des universités partenaires', 13, 'TEXT'),
('Type d''échange (étudiants, enseignants)', 13, 'VARCHAR(255)'),
('Durée de l''échange', 13, 'VARCHAR(100)'),
('Nombre de bénéficiaires', 13, 'INT'),
('Modalités de reconnaissance académique', 13, 'TEXT'),
('Responsable de suivi', 13, 'VARCHAR(190)');

-- Convention de coopération internationale (id = 14)
INSERT INTO type_conventions_attribution (nom_champ, type_convention_id, Type_nom_champ)
VALUES
('Nom du pays / institution partenaire', 14, 'VARCHAR(190)'),
('Objectif de la coopération', 14, 'TEXT'),
('Durée', 14, 'VARCHAR(100)'),
('Budget ou financement', 14, 'DECIMAL(50,2)'),
('Engagements des parties', 14, 'TEXT'),
('Suivi et évaluation', 14, 'TEXT');



INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
VALUES
-- Convention commerciale (type 1) -> lois 'Loi relative a la convention commerciale ...'
((SELECT id FROM types_convention WHERE nom='Convention commerciale'),
 'Societe Manja c/ Commune Antananarivo', 'ARRET n°023/CCOM-2023', '2023-11-15',
 'Cour de cassation - Chambre commerciale',
 'La cour confirme la nullite d une clause de prix non determine dans un contrat de fourniture.',
 (SELECT id FROM lois WHERE numero_loi='LOI-354/2001'),
 'Bulletin des decisions judiciaires MG 2023'),

((SELECT id FROM types_convention WHERE nom='Convention commerciale'),
 'Ets Ravinala c/ Societe Iarivo', 'ORDONNANCE n°112/TC-ANT-2024', '2024-06-07',
 'Tribunal de commerce d Antananarivo',
 'Mesure conservatoire autorisee pour prevenir la dissipation d actifs avant arbitrage.',
 (SELECT id FROM lois WHERE numero_loi='LOI-673/2015'),
 'Greffe TC Antananarivo - Registre 2024'),

-- Convention interne (type 2)
((SELECT id FROM types_convention WHERE nom='Convention interne'),
 'Universite Publique c/ Agent administratif X', 'ARRET n°045/CA-TA-2021', '2021-03-29',
 'Cour d appel de Toamasina - Chambre administrative',
 'La procedure disciplinaire interne est validee des lors que le droit de defense a ete respecte.',
 (SELECT id FROM lois WHERE numero_loi='LOI-458/2012'),
 'Recueil administratif TA Toamasina'),

((SELECT id FROM types_convention WHERE nom='Convention interne'),
 'Ministere Y c/ Syndicat Z', 'JUGEMENT n°078/TA-ANT-2022', '2022-10-14',
 'Tribunal administratif d Antananarivo',
 'Annulation partielle d une note interne pour vice de competence.',
 (SELECT id FROM lois WHERE numero_loi='LOI-290/2020'),
 'TA Antananarivo - Role contentieux 2022'),

-- Convention financiere (type 3)
((SELECT id FROM types_convention WHERE nom='Convention financière'),
 'Banque MG c/ Societe Volamena', 'ARRET n°131/CCOM-2024', '2024-02-13',
 'Cour de cassation - Chambre commerciale',
 'La clause d interet variable est licite si l indice de refference est objectif et public.',
 (SELECT id FROM lois WHERE numero_loi='LOI-559/2011'),
 'Bulletin des banques et finances 2024'),

((SELECT id FROM types_convention WHERE nom='Convention financière'),
 'Fonds Aro c/ Entreprise Koba', 'JUGEMENT n°056/TPI-TMA-2023', '2023-09-28',
 'Tribunal de premiere instance de Toamasina - Section commerciale',
 'Requalification d une avance en pret avec obligation de restitution.',
 (SELECT id FROM lois WHERE numero_loi='LOI-361/2018'),
 'Greffe TPI Toamasina - Plumitif 2023'),

-- Convention de partenariat (type 4)
((SELECT id FROM types_convention WHERE nom='Convention de partenariat'),
 'Region Analamanga c/ ONG Fihavaozana', 'ARRET n°089/CA-ANT-2021', '2021-08-10',
 'Cour d appel d Antananarivo - Chambre administrative',
 'La resiliation unilaterale du partenariat est fautive en absence de motif d interet general.',
 (SELECT id FROM lois WHERE numero_loi='LOI-574/2012'),
 'Revue de droit public MG, 2021'),

((SELECT id FROM types_convention WHERE nom='Convention de partenariat'),
 'Commune Tamatave c/ Societe Fanorenana', 'JUGEMENT n°144/TA-TMA-2020', '2020-11-07',
 'Tribunal administratif de Toamasina',
 'Le suivi-evaluation contractuel rend une penalite contractuelle exigible.',
 (SELECT id FROM lois WHERE numero_loi='LOI-795/2002'),
 'TA Toamasina - Bulletin 2020'),

-- Conventions specifiques (type 5)
((SELECT id FROM types_convention WHERE nom='Conventions spécifiques'),
 'Projet Tantsaha c/ Ministere Agriculture', 'ARRET n°072/CA-ANT-2019', '2019-06-27',
 'Cour d appel d Antananarivo - Chambre administrative',
 'Validation d une clause technique imposee par bailleur pour conformite aux normes.',
 (SELECT id FROM lois WHERE numero_loi='LOI-538/2007'),
 'Recueil administratif national 2019'),

((SELECT id FROM types_convention WHERE nom='Conventions spécifiques'),
 'Societe Enera c/ Agence Publique Energie', 'JUGEMENT n°031/TPI-MJG-2014', '2014-05-12',
 'Tribunal de premiere instance de Mahajanga - Section civile',
 'Responsabilite partagee a 50 pour cent pour retard d execution lie a la logistique.',
 (SELECT id FROM lois WHERE numero_loi='LOI-733/2000'),
 'Greffe TPI Mahajanga - Cahier civil 2014');



INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
VALUES
-- Convention de collaboration (type 6)
((SELECT id FROM types_convention WHERE nom='Convention de collaboration'),
 'Universite Antsiranana c/ Centre Recherche X', 'ARRET n°017/CA-ATS-2025', '2025-02-28',
 'Cour d appel d Antsiranana',
 'La copropriete des resultats s apprecie selon la contribution effective des parties.',
 (SELECT id FROM lois WHERE numero_loi='LOI-276/2017'),
 'Revue scientifique MG 2025'),

((SELECT id FROM types_convention WHERE nom='Convention de collaboration'),
 'Hopital HJRA c/ Association MIASA', 'JUGEMENT n°209/TPI-ANT-2017', '2017-12-11',
 'Tribunal de premiere instance d Antananarivo',
 'La convention exige l approbation de l organe de tutelle pour produire effet.',
 (SELECT id FROM lois WHERE numero_loi='LOI-652/2001'),
 'Greffe TPI Antananarivo - Registre 2017'),

-- Convention de stage (type 7)
((SELECT id FROM types_convention WHERE nom='Convention de stage'),
 'Etudiant A c/ Societe Logistique', 'JUGEMENT n°098/TDT-ANT-2021', '2021-06-03',
 'Tribunal du travail d Antananarivo',
 'Requalification refusee: le stage n etablit pas un contrat de travail sans lien de subordination.',
 (SELECT id FROM lois WHERE numero_loi='LOI-671/2017'),
 'Chronique sociale MG 2021');



INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
VALUES
((SELECT id FROM types_convention WHERE nom='Convention de stage'),
 'Ecole Pro c/ Etudiante B', 'ARRET n°055/CA-TLI-2020', '2020-09-16',
 'Cour d appel de Toliara',
 'L organisme d accueil est tenu a une obligation de securite renforcee.',
 (SELECT id FROM lois WHERE numero_loi='LOI-644/2004'),
 'Bulletin de jurisprudence sociale 2020'),

-- Convention de recherche (type 8)
((SELECT id FROM types_convention WHERE nom='Convention de recherche'),
 'Centre Bio c/ Lab Ocean Indien', 'ARRET n°103/CCIV-2019', '2019-09-10',
 'Cour de cassation - Chambre civile',
 'La confidentialite s applique aux donnees brutes et aux rapports intermediaires.',
 (SELECT id FROM lois WHERE numero_loi='LOI-449/2020'),
 'Bulletin Cour supreme 2019'),

((SELECT id FROM types_convention WHERE nom='Convention de recherche'),
 'Institut Tech c/ Start-up Z', 'JUGEMENT n°041/TPI-FNR-2012', '2012-10-31',
 'Tribunal de premiere instance de Fianarantsoa',
 'La propriete intellectuelle est partagee sauf stipulation expresse contraire.',
 (SELECT id FROM lois WHERE numero_loi='LOI-687/2013'),
 'Greffe TPI Fianarantsoa 2012');









INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
VALUES
-- Convention de sous-traitance (type 9)
((SELECT id FROM types_convention WHERE nom='Convention de sous-traitance'),
 'Entreprise BTP c/ Sous-traitant R', 'ARRET n°077/CCOM-2021', '2021-10-30',
 'Cour de cassation - Chambre commerciale',
 'La solidarite de paiement s applique si le donneur d ordre a valide les situations de travaux.', (SELECT id FROM lois WHERE numero_loi='LOI-640/2013'),
 'Revue BTP & Droit MG 2021');



INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
VALUES
((SELECT id FROM types_convention WHERE nom='Convention de sous-traitance'),
 'Port Toamasina c/ Operateur Log', 'JUGEMENT n°115/TPI-TMA-2021', '2021-01-18',
 'Tribunal de premiere instance de Toamasina - Section commerciale',
 'La clause penale est reduite pour exces manifeste au regard du prejudice.',
 (SELECT id FROM lois WHERE numero_loi='LOI-372/2021'),'Greffe TPI Toamasina - Registre comm. 2021');


INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
SELECT 
    tc.id,
    'Commune X c/ Expert International',
    'ARRET n°066/CA-ANT-2019',
    '2019-04-25',
    'Cour d appel d Antananarivo - Chambre administrative',
    'Obligation de resultat exclue: mission d assistance de moyens.',
    l.id,
    'Recueil administratif 2019'
FROM types_convention tc
JOIN lois l
ON l.numero_loi = 'LOI-566/2014'
WHERE tc.nom = 'Convention d\'assistance technique';








-- Convention d’assistance technique (type 10)
INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
SELECT 
    tc.id,
    'Agence Eau c/ Cabinet Tech',
    'JUGEMENT n°022/TPI-MJG-2015',
    '2015-01-22',
    'Tribunal de premiere instance de Mahajanga',
    'Le rapport final conditionne le solde du marche d assistance.',
    l.id,
    'Greffe TPI Mahajanga 2015'
FROM types_convention tc
JOIN lois l ON l.numero_loi = 'LOI-437/2024'
WHERE tc.nom = 'Convention d\'assistance technique';

-- Convention de formation (type 11)
INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
SELECT 
    tc.id,
    'Chambre Metiers c/ Centre Form MG',
    'ARRET n°091/CA-ATS-2014',
    '2014-05-27',
    'Cour d appel d Antsiranana',
    'La formation doit correspondre aux besoins identifies du marche local pour ouvrir droit au financement.',
    l.id,
    'Revue education & emploi 2014'
FROM types_convention tc
JOIN lois l ON l.numero_loi = 'LOI-727/2017'
WHERE tc.nom = 'Convention de formation';

INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
SELECT 
    tc.id,
    'Entreprise Telma c/ Stagiaire Pro',
    'JUGEMENT n°067/TDT-ANT-2023',
    '2023-07-08',
    'Tribunal du travail d Antananarivo',
    'Le refus de certification est legal en cas d assiduite insuffisante justifiee.',
    l.id,
    'Chronique sociale MG 2023'
FROM types_convention tc
JOIN lois l ON l.numero_loi = 'LOI-582/2000'
WHERE tc.nom = 'Convention de formation';

-- Convention de prestation de services (type 12)
INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
SELECT 
    tc.id,
    'Societe Numerika c/ Ministere Finances',
    'ARRET n°119/CCOM-2022',
    '2022-12-15',
    'Cour de cassation - Chambre commerciale',
    'Le retard d execution justifie une penalite si les causes ne sont pas imputables au client public.',
    l.id,
    'Bulletin jurisprudence commerciale 2022'
FROM types_convention tc
JOIN lois l ON l.numero_loi = 'LOI-773/2024'
WHERE tc.nom = 'Convention de prestation de services';

INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
SELECT 
    tc.id,
    'Hopital Regional c/ Prestataire Hygiene',
    'JUGEMENT n°033/TPI-TLI-2020',
    '2020-02-04',
    'Tribunal de premiere instance de Toliara',
    'L obligation de resultat est retenue pour la desinfection des blocs operatoires.',
    l.id,
    'Greffe TPI Toliara - Hygiene 2020'
FROM types_convention tc
JOIN lois l ON l.numero_loi = 'LOI-619/2009'
WHERE tc.nom = 'Convention de prestation de services';

-- Convention d’echange universitaire (type 13)
INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
SELECT 
    tc.id,
    'Universite Antananarivo c/ Universite Partenaire',
    'ARRET n°057/CA-ANT-2019',
    '2019-06-19',
    'Cour d appel d Antananarivo - Chambre administrative',
    'Reconnaissance des credits garantie par clause expresse et commission paritaire.',
    l.id,
    'Revue de l enseignement superieur MG 2019'
FROM types_convention tc
JOIN lois l ON l.numero_loi = 'LOI-639/2021'
WHERE tc.nom = 'Convention d\'echange universitaire';

INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
SELECT 
    tc.id,
    'Ecole Sup X c/ Etudiant E',
    'JUGEMENT n°024/TA-ANT-2017',
    '2017-07-21',
    'Tribunal administratif d Antananarivo',
    'Annulation d un refus d equivalence faute de motivation suffisante.',
    l.id,
    'TA Antananarivo - Base contentieux 2017'
FROM types_convention tc
JOIN lois l ON l.numero_loi = 'LOI-721/2023'
WHERE tc.nom = 'Convention d\'echange universitaire';

-- Convention de coopération internationale (type 14)
INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
SELECT 
    tc.id,
    'Etat MG c/ Agence Internationale',
    'ARRET n°041/CA-ANT-2019',
    '2019-07-17',
    'Cour d appel d Antananarivo - Chambre administrative',
    'Les accords doivent etre ratifies selon la procedure nationale avant execution.',
    l.id,
    'Recueil de droit international MG 2019'
FROM types_convention tc
JOIN lois l ON l.numero_loi = 'LOI-815/2015'
WHERE tc.nom = 'Convention de coopération internationale';

INSERT INTO jurisprudences
(types_convention_id, titre, refference, date_de_creation, juridiction, resume, lois_id, source)
SELECT 
    tc.id,
    'Projet Eau Rurale c/ Consortium Z',
    'JUGEMENT n°052/TPI-FNR-2014',
    '2014-03-08',
    'Tribunal de premiere instance de Fianarantsoa',
    'La clause d appropriation nationale prime sur une stipulation contraire non ratifiee.',
    l.id,
    'Greffe TPI Fianarantsoa 2014'
FROM types_convention tc
JOIN lois l ON l.numero_loi = 'LOI-320/2004'
WHERE tc.nom = 'Convention de coopération internationale';
