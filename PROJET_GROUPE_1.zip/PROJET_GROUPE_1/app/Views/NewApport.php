<?php
require_once 'app/Core/Database.php';

// Récupération des ID transmis
$societe_id = $_GET['societe_id'] ?? null;
$actionnaire_id = $_GET['actionnaire_id'] ?? null;

// Connexion à la base
$db = Database::getConnection();
$typeApports = $db->query("SELECT * FROM type_apports")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Nouvel Apport</title>
</head>
<body>
    <h2>Nouvel apport</h2>

    <form method="POST" action="index.php?action=save_apport">
        <input type="hidden" name="societe_id" value="<?= htmlspecialchars($societe_id) ?>">
        <input type="hidden" name="actionnaire_id" value="<?= htmlspecialchars($actionnaire_id) ?>">

        <label for="type_apport">Type d’apport :</label>
        <select name="type_apport_id" id="type_apport" required>
            <?php foreach ($typeApports as $type): ?>
                <option value="<?= $type['id'] ?>"><?= htmlspecialchars($type['nom']) ?></option>
            <?php endforeach; ?>
        </select>
        <br><br>

        <label for="montant">Montant (optionnel) :</label>
        <input type="number" name="montant" step="0.01" id="montant">
        <br><br>

        <label for="description">Description :</label>
        <textarea name="description" id="description"></textarea>
        <br><br>

        <button type="submit">Valider</button>
    </form>
</body>
</html>
