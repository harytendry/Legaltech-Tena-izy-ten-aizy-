<!DOCTYPE html>
<html>
<head>
  <title>Inscription - LegalTech</title>
</head>
<body>
  <h2>Créer un compte</h2>
  <form method="POST" action="">
    <label>Nom :</label>
    <input type="text" name="nom" required><br>
    <label>Email :</label>
    <input type="email" name="email" required><br>
    <label>Mot de passe :</label>
    <input type="password" name="password" required><br>
    <button type="submit">S'inscrire</button>
  </form>
  <a href="index.php?action=login">Déjà inscrit ? Connecte-toi</a>
</body>
</html>
