<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Inscription d'une société - LegalTech</title>
<style>
  body { font-family: Arial, sans-serif; background:#f7f7f7; padding:24px; }
  .card { max-width:720px; margin:0 auto; background:#fff; padding:24px; border-radius:10px; box-shadow:0 6px 18px rgba(0,0,0,.06); }
  h2 { margin-top:0; }
  .row { display:flex; gap:16px; }
  .row .col { flex:1; }
  label { display:block; font-weight:bold; margin-top:14px; margin-bottom:6px; }
  input[type="text"], input[type="date"], input[type="number"], select {
    width:100%; padding:10px; border:1px solid #ddd; border-radius:6px;
  }
  .actions { margin-top:20px; display:flex; gap:10px; }
  .btn { padding:10px 16px; border:none; border-radius:6px; cursor:pointer; }
  .btn-primary { background:#2563eb; color:#fff; }
  .btn-secondary { background:#e5e7eb; color:#111827; text-decoration:none; display:inline-block; }
  .errors { background:#fee2e2; color:#991b1b; border:1px solid #fecaca; padding:12px; border-radius:6px; margin-bottom:12px; }
</style>
</head>

<?php if (!empty($popupMessage)): ?>
<script>
  alert(<?= json_encode($popupMessage, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>);
</script>
<?php endif; ?>


<body>
<div class="card">
  <h2>Créer une société</h2>

  <?php if (!empty($errors)): ?>
    <div class="errors">
      <ul>
        <?php foreach ($errors as $e): ?>
          <li><?= htmlspecialchars($e) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="POST" action="">
    <label for="type_societe_id">Choix du type de société</label>
    <select id="type_societe_id" name="type_societe_id" required>
      <option value="">-- Sélectionner --</option>
      <?php foreach ($types as $t): ?>
        <option value="<?= (int)$t['id'] ?>"
          <?= (isset($_POST['type_societe_id']) && (int)$_POST['type_societe_id'] === (int)$t['id']) ? 'selected' : '' ?>>
          <?= htmlspecialchars($t['nom']) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <label for="nom">Nom</label>
    <input type="text" id="nom" name="nom"
           value="<?= htmlspecialchars($_POST['nom'] ?? 'Ma Société SARL') ?>" required>

    <label for="siege">Siège</label>
    <input type="text" id="siege" name="siege"
           value="<?= htmlspecialchars($_POST['siege'] ?? 'Antananarivo, Madagascar') ?>">

    <div class="row">
      <div class="col">
        <label for="date_creation">Date de création</label>
        <input type="date" id="date_creation" name="date_creation"
               value="<?= htmlspecialchars($_POST['date_creation'] ?? '') ?>">
      </div>
      <div class="col">
        <label for="capital">Capital (Ar)</label>
        <input type="number" step="0.01" id="capital" name="capital"
               value="<?= htmlspecialchars($_POST['capital'] ?? '0') ?>">
      </div>
    </div>

    <div class="row">
      <div class="col">
        <label for="duree_vie">Durée de vie (années)</label>
        <input type="number" id="duree_vie" name="duree_vie" min="1"
               value="<?= htmlspecialchars($_POST['duree_vie'] ?? '99') ?>">
      </div>
      <div class="col">
        <label for="objet_social">Objet social</label>
        <input type="text" id="objet_social" name="objet_social"
               value="<?= htmlspecialchars($_POST['objet_social'] ?? 'Conseil et prestations de services') ?>">
      </div>
    </div>

    <div class="actions">
      <button type="submit" class="btn btn-primary">Enregistrer</button>
      <a class="btn btn-secondary" href="index.php?action=mes_societes">Annuler</a>
    </div>
  </form>
</div>
</body>
</html>
