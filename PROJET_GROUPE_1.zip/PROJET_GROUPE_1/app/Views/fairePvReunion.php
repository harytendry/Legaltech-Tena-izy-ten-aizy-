<?php
// $info = réunion avec ses participants (passée depuis le contrôleur)
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Procès-Verbal de Réunion</title>
    <style>
        body { font-family: Arial; background:#f5f5f5; padding:20px; }
        .card { background:#fff; padding:20px; border-radius:10px; margin-bottom:20px; }
        .group { margin-bottom:15px; }
        .btn { padding:10px 16px; border:none; border-radius:8px; cursor:pointer; }
        .btn-blue { background:#0275d8; color:#fff; }
        .btn-add { background:#eee; border:1px solid #aaa; cursor:pointer; }
    </style>
    <script>
        function addDecision() {
            const container = document.getElementById("decisions");
            const div = document.createElement("div");
            div.classList.add("group");
            div.innerHTML = `<input type="text" name="decisions[]" placeholder="Décision prise" style="width:100%;padding:8px;">`;
            container.appendChild(div);
        }
    </script>
</head>
<body>

<div class="card">
    <h2>Résumé de la réunion</h2>
    <p><strong>Date et heure :</strong> <?= htmlspecialchars($info['date']) ?> à <?= htmlspecialchars(substr($info['heure'],0,5)) ?></p>
    <p><strong>Lieu :</strong> <?= htmlspecialchars($info['lieu']) ?></p>
    <p><strong>Objet :</strong> <?= htmlspecialchars($info['objet']) ?></p>
    <p><strong>Type :</strong> <?= htmlspecialchars($info['nom_reunion']) ?></p>
</div>

<form method="POST" action="index.php?action=save_pv">
    <input type="hidden" name="id_reunion" value="<?= $info['id'] ?>">
    <input type="hidden" name="societe_id" value="<?= $info['societe_id'] ?>">

    <div class="card">
        <h3>Décisions prises</h3>
        <div id="decisions">
            <div class="group">
                <input type="text" name="decisions[]" placeholder="Décision prise" style="width:100%;padding:8px;">
            </div>
        </div>
        <button type="button" class="btn-add" onclick="addDecision()">+ Ajouter une décision</button>
    </div>

    <div class="card">
        <h3>Participants (cocher les absents)</h3>
        <?php foreach ($info['participants'] as $p): ?>
            <div>
                <label>
                    <input type="checkbox" name="absents[]" value="<?= $p['id'] ?>">
                    <?= htmlspecialchars($p['nom']) ?> (<?= htmlspecialchars($p['post']) ?>)
                </label>
            </div>
        <?php endforeach; ?>
    </div>

    <button type="submit" class="btn btn-blue">Valider le PV</button>
</form>

</body>
</html>
