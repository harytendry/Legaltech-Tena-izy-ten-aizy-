<?php
// Reçoit $societe (avec id, nom, etat), $roles, $errors depuis le contrôleur
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Ajouter un actionnaire - <?= h($societe['nom']) ?></title>
<style>
  body { font-family: Arial, sans-serif; background:#f7f7f7; padding:24px; }
  .card { max-width:720px; margin:0 auto; background:#fff; padding:24px; border-radius:12px; box-shadow:0 8px 22px rgba(0,0,0,.08); }
  h2 { margin:0 0 10px; }
  .subtitle { color:#6b7280; margin-bottom:16px; }
  label { display:block; font-weight:600; margin:14px 0 6px; }
  input[type="text"], select {
    width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;
  }
  .actions { margin-top:20px; display:flex; gap:10px; flex-wrap:wrap; }
  .btn { padding:10px 16px; border:none; border-radius:8px; cursor:pointer; text-decoration:none; display:inline-block; }
  .btn-primary { background:#10b981; color:#fff; }
  .btn-light { background:#e5e7eb; color:#111827; }
  .errors { background:#fee2e2; color:#991b1b; border:1px solid #fecaca; padding:12px; border-radius:8px; }
</style>
</head>
<body>
<div class="card">
  <h2>Ajouter un actionnaire</h2>
  <div class="subtitle">Société : <strong><?= h($societe['nom']) ?></strong></div>

  <?php if (!empty($errors)): ?>
    <div class="errors">
      <ul>
        <?php foreach ($errors as $e): ?>
          <li><?= h($e) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="POST" action="">
    <label for="nom">Nom complet</label>
    <input type="text" id="nom" name="nom" required
           value="<?= h($_POST['nom'] ?? '') ?>">

    <label for="roleActionnaire_id">Rôle</label>
    <select id="roleActionnaire_id" name="roleActionnaire_id" required>
      <option value="">-- Sélectionner --</option>
      <?php foreach ($roles as $r): ?>
        <option value="<?= (int)$r['id'] ?>"
          <?= (isset($_POST['roleActionnaire_id']) && (int)$_POST['roleActionnaire_id'] === (int)$r['id']) ? 'selected' : '' ?>>
          <?= h($r['nom_role_actionnaires']) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <div class="actions">
      <button type="submit" class="btn btn-primary">Enregistrer</button>
      <a class="btn btn-light" href="index.php?action=dashboard_societe&id=<?= (int)$societe['id'] ?>">Annuler</a>
    </div>
  </form>
</div>
</body>
</html>
