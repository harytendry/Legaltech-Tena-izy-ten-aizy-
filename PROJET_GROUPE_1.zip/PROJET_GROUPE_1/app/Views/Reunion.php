<?php
require_once 'app/Core/Database.php';

$societe_id = $_GET['societe_id'] ?? null;

// Charger les types de réunions
$db = Database::getConnection();
$typeReunions = $db->query("SELECT * FROM type_reunions")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Réunions</title>
    <script>
        // Ajouter dynamiquement des champs "participant"
        function addParticipant() {
            const container = document.getElementById("participants");
            const div = document.createElement("div");
            div.classList.add("participant");

            div.innerHTML = `
                <label>Nom :</label>
                <input type="text" name="participants[nom][]" required>
                <label>Poste :</label>
                <input type="text" name="participants[post][]" required>
                <br><br>
            `;

            container.appendChild(div);
        }
    </script>
</head>
<body>
    <h2>Créer une Réunion</h2>

    <form method="POST" action="index.php?action=save_reunion">
        <input type="hidden" name="societe_id" value="<?= htmlspecialchars($societe_id) ?>">

        <label for="date">Date :</label>
        <input type="date" name="date" required><br><br>

        <label for="heure">Heure :</label>
        <input type="time" name="heure" required><br><br>

        <label for="objet">Objet :</label>
        <input type="text" name="objet" required><br><br>

        <label for="lieu">Lieu :</label>
        <input type="text" name="lieu" required><br><br>

        <label for="type_reunion">Type de réunion :</label>
        <select name="type_reunion_id" required>
            <?php foreach ($typeReunions as $type): ?>
                <option value="<?= $type['id'] ?>"><?= htmlspecialchars($type['nom_reunion']) ?></option>
            <?php endforeach; ?>
        </select>
        <br><br>

        <h3>Participants</h3>
        <div id="participants">
            <div class="participant">
                <label>Nom :</label>
                <input type="text" name="participants[nom][]" required>
                <label>Poste :</label>
                <input type="text" name="participants[post][]" required>
                <br><br>
            </div>
        </div>
        <button type="button" onclick="addParticipant()">+ Ajouter un participant</button>
        <br><br>

        <button type="submit">Créer la réunion</button>
    </form>



    <div class="panel">
    <h2>Liste des réunions</h2>

    <?php if (!empty($reunions)) : ?>
        <?php foreach ($reunions as $r): ?>
            <div class="card">
                <p><strong>Date et heure :</strong> <?= htmlspecialchars($r['date']) ?> à <?= htmlspecialchars(substr($r['heure'], 0, 5)) ?></p>
                <p><strong>Lieu :</strong> <?= htmlspecialchars($r['lieu']) ?></p>
                <p><strong>Objet :</strong> <?= htmlspecialchars($r['objet']) ?></p>
                <p><strong>Type de réunion :</strong> <?= htmlspecialchars($r['nom_reunion']) ?></p>
                <p><strong>Participants :</strong>
                    <?php if (!empty($r['participants'])): ?>
                        <?php foreach ($r['participants'] as $p): ?>
                            <?= htmlspecialchars($p['nom']) ?> (<?= htmlspecialchars($p['post']) ?>),
                        <?php endforeach; ?>
                    <?php else: ?>
                        <em>Aucun participant</em>
                    <?php endif; ?>
                </p>

                <?php if ((int)$r['deja_passe'] === 0): ?>


<a href="index.php?action=faire_pv&id=<?= $r['id'] ?>">
    <button class="btn btn-red">Faire un Procès verbal</button>
</a>


<?php else: ?>
    <a href="index.php?action=voir_pv&id=<?= $r['id'] ?>">
        <button class="btn btn-blue">Voir</button>
    </a>
<?php endif; ?>



            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Aucune réunion créée pour l’instant.</p>
    <?php endif; ?>
</div>

</body>
</html>
