<?php
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Mes Sociétés - LegalTech</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f6f6f6;
      padding: 20px;
    }

    h2 {
      color: #333;
      margin-bottom: 20px;
    }

    .societe {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 20px;
      color: white;
      margin-bottom: 8px;
      border-radius: 6px;
      font-size: 16px;
    }

    .actif {
      background-color: #28a745; /* vert */
    }

    .dissous {
      background-color: #c82333; /* rouge */
    }

    .add-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 35px;
      height: 35px;
      border: 1px solid #888;
      border-radius: 5px;
      color: #444;
      text-decoration: none;
      font-size: 22px;
      margin-top: 10px;
    }

    .add-btn:hover {
      background: #e8e8e8;
    }

    .container {
      max-width: 500px;
      background: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Mes sociétés (<?= count($societes) ?>)</h2>

  <?php if (empty($societes)) : ?>
    <p>Aucune société enregistrée.</p>
  <?php else : ?>


<?php foreach ($societes as $s): 
  $id   = isset($s['id'])   ? (int)$s['id'] : 0;
  $nom  = isset($s['nom'])  ? $s['nom']    : 'Non précisé';
  $etat = isset($s['etat']) ? $s['etat']   : 'actif'; // défaut visuel vert
?>
  <a class="societe <?= htmlspecialchars($etat) ?>"
     href="index.php?action=dashboard_societe&id=<?= $id ?>">
    <span><?= htmlspecialchars($nom) ?></span>
    <span><?= htmlspecialchars($etat) ?></span>
  </a>
<?php endforeach; ?>


  <?php endif; ?>

  <a href="index.php?action=inscription_societe" class="add-btn">+</a>
</div>

</body>
</html>
