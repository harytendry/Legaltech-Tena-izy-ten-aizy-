<?php
// Reçoit $societe (avec ses champs) et $types depuis le contrôleur
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Modifier la société - <?= h($societe['nom'] ?? 'Société') ?></title>
<style>
  body { font-family: Arial, sans-serif; background:#f7f7f7; padding:24px; }
  .card { max-width:780px; margin:0 auto; background:#fff; padding:24px; border-radius:12px; box-shadow:0 8px 22px rgba(0,0,0,.08); }
  h2 { margin-top:0; }
  label { display:block; font-weight:600; margin:14px 0 6px; }
  input[type="text"], input[type="number"], select {
    width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;
  }
  .row { display:flex; gap:16px; }
  .col { flex:1; }
  .actions { margin-top:20px; display:flex; gap:10px; flex-wrap:wrap; }
  .btn { padding:10px 16px; border:none; border-radius:8px; cursor:pointer; text-decoration:none; display:inline-block; }
  .btn-primary { background:#2563eb; color:#fff; }
  .btn-light { background:#e5e7eb; color:#111827; }
  .errors { background:#fee2e2; color:#991b1b; border:1px solid #fecaca; padding:12px; border-radius:8px; }
</style>
</head>
<body>
<div class="card">
  <h2>Modifier la société</h2>

  <?php if (!empty($errors)): ?>
    <div class="errors">
      <ul>
        <?php foreach ($errors as $e): ?>
          <li><?= h($e) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="POST" action="">
    <label for="nom">Nom</label>
    <input type="text" id="nom" name="nom" required
           value="<?= h($societe['nom'] ?? '') ?>">

    <label for="type_societe_id">Type de société</label>
    <select id="type_societe_id" name="type_societe_id" required>
      <option value="">-- Sélectionner --</option>
      <?php foreach ($types as $t): ?>
        <option value="<?= (int)$t['id'] ?>"
          <?= ((int)($societe['type_societe_id'] ?? 0) === (int)$t['id']) ? 'selected' : '' ?>>
          <?= h($t['nom']) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <label for="siege">Siège</label>
    <input type="text" id="siege" name="siege"
           value="<?= h($societe['siege'] ?? '') ?>">

    <div class="row">
      <div class="col">
        <label for="capital">Capital (Ar)</label>
        <input type="number" id="capital" name="capital" step="0.01" min="0"
               value="<?= h($societe['capital'] ?? '0') ?>">
      </div>
      <div class="col">
        <label for="duree_vie">Durée de vie (années)</label>
        <input type="number" id="duree_vie" name="duree_vie" min="1"
               value="<?= h($societe['duree_vie'] ?? '') ?>">
      </div>
    </div>

    <label for="objet_social">Objet social</label>
    <input type="text" id="objet_social" name="objet_social"
           value="<?= h($societe['objet_social'] ?? '') ?>">

    <div class="actions">
      <button type="submit" class="btn btn-primary">Enregistrer</button>
      <a class="btn btn-light" href="index.php?action=dashboard_societe&id=<?= (int)$societe['id'] ?>">Annuler</a>
    </div>
  </form>
</div>

</body>
</html>
