<?php
// dashboard_societe.php
// Reçoit $societe depuis SocieteController::dashboardSociete()

// Helpers d'affichage
function showOrNA($val) {
    if ($val === null || $val === '') return 'Non précisé';
    return htmlspecialchars((string)$val, ENT_QUOTES, 'UTF-8');
}
function showDateOrNA($dateStr) {
    if ($dateStr === null || $dateStr === '') return 'Non précisé';
    $ts = strtotime($dateStr);
    return $ts ? date('d/m/Y', $ts) : 'Non précisé';
}
function showMoneyOrNA($amount) {
    if ($amount === null || $amount === '') return 'Non précisé';
    $num = (float)$amount;
    return number_format($num, 0, ',', ' ') . ' Ar';
}

$isDissous = (isset($societe['etat']) && $societe['etat'] === 'dissous');
$idSoc     = (int)$societe['id'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Fiche société - <?= htmlspecialchars($societe['nom'] ?? 'Société') ?></title>
<style>

.actionnaires-section {
  margin-top: 50px;
  background: #fff;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,.05);
}
.actionnaires-section h3 { margin-bottom: 16px; }

.filter-row {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: 16px;
}
.filter-row select {
  padding: 6px 10px; border-radius: 6px; border:1px solid #d1d5db;
}

.actionnaires-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 18px;
}
.actionnaire-card {
  background: #f9fafb;
  border-radius: 10px;
  padding: 14px 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.08);
}
.actionnaire-card p { margin: 6px 0; font-size: 14px; }
.btn-apropos {
  display: inline-block;
  margin-top: 8px;
  padding: 6px 12px;
  border-radius: 8px;
  background: #2563eb;
  color: #fff;
  text-decoration: none;
  font-size: 13px;
}

.add-actionnaire {
  margin-top: 20px;
  text-align: right;
}
.btn-add {
  background:#10b981;
  color:#fff;
  padding:10px 18px;
  border-radius:999px;
  text-decoration:none;
  font-weight:600;
}
.btn-add:hover { background:#059669; }

.btn-add-disabled {
  background:#9ca3af;
  color:#f9fafb;
  padding:10px 18px;
  border-radius:999px;
  border:none;
}
.disabled { opacity:0.7; pointer-events:none; }



  body { font-family: Arial, sans-serif; background:#f7f7f7; padding:24px; }
  .card { max-width:820px; margin:0 auto; background:#fff; padding:24px; border-radius:12px; box-shadow:0 8px 22px rgba(0,0,0,.08); }
  h2 { margin:0 0 8px; font-size:24px; }
  .status { display:inline-block; padding:4px 10px; border-radius:999px; font-size:12px; color:#fff; margin-top:6px; }
  .status.actif { background:#16a34a; }
  .status.dissous { background:#dc2626; }

  .grid { display:grid; grid-template-columns: 220px 1fr; gap:10px 16px; margin-top:18px; }
  .label { color:#6b7280; }
  .value { color:#111827; font-weight:600; }

  .actions { margin-top:22px; display:flex; gap:10px; flex-wrap:wrap; }
  .btn { padding:10px 16px; border:none; border-radius:8px; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; justify-content:center; }
  .btn-primary { background:#2563eb; color:#fff; }
  .btn-light { background:#e5e7eb; color:#111827; }

  /* Boutons pastilles avec barre blanche */
  .danger-pill, .success-pill {
    width: 48px; height: 32px; border-radius: 999px; border: none; cursor: pointer;
    position: relative; display: inline-flex; align-items: center; justify-content: center;
  }
  .danger-pill { background: #ef4444; }   /* rouge */
  .success-pill { background: #16a34a; }  /* vert  */
  .white-bar { width: 18px; height: 4px; background: #fff; border-radius: 2px; display: block; }

  /* Modale “mini page JSON” */
  .modal-root {
    position: fixed; inset: 0; background: rgba(0,0,0,.35);
    display: none; align-items: center; justify-content: center; z-index: 9999;
  }
  .modal-card {
    width: 420px; max-width: 92vw; background: #fff; border-radius: 16px;
    box-shadow: 0 18px 45px rgba(0,0,0,.18);
    padding: 18px 18px 14px;
  }
  .modal-title { font-size: 20px; font-weight: 700; margin: 0 0 6px; }
  .modal-sub { color:#6b7280; margin: 0 0 14px; line-height:1.35; }

  .chips { display:flex; flex-wrap:wrap; gap:10px; margin: 10px 0 12px; }
  .chip {
    padding: 8px 14px; border-radius: 10px; background:#f1f5f9; cursor:pointer;
    border:1px solid #e5e7eb; user-select:none;
  }
  .chip.active { background:#3b82f6; color:#fff; border-color:#3b82f6; }

  .modal-actions { display:flex; justify-content:flex-end; gap:10px; margin-top: 10px; }
  .btn-ghost { background:#e5e7eb; color:#111827; }
  .btn-red { background:#ef4444; color:#fff; }
  .btn-green { background:#16a34a; color:#fff; }

  /* petits ajustements responsive */
  @media (max-width: 560px) {
    .grid { grid-template-columns: 1fr; }
    .label { color:#374151; font-weight:600; margin-top:6px; }
    .value { font-weight:500; }
  }
</style>
</head>
<body>
<div class="card">
  <h2><?= htmlspecialchars($societe['nom'] ?? 'Société') ?></h2>
  <div>
    <span class="status <?= htmlspecialchars($societe['etat'] ?? 'actif') ?>">
      <?= htmlspecialchars($societe['etat'] ?? 'actif') ?>
    </span>
  </div>

  <div class="grid">
    <div class="label">Nom de la société</div>
    <div class="value"><?= showOrNA($societe['nom'] ?? null) ?></div>

    <div class="label">Siège social</div>
    <div class="value"><?= showOrNA($societe['siege'] ?? null) ?></div>

    <div class="label">Type de société</div>
    <div class="value"><?= showOrNA($societe['type_societe_nom'] ?? null) ?></div>

    <div class="label">Date de création</div>
    <div class="value"><?= showDateOrNA($societe['date_creation'] ?? null) ?></div>

    <div class="label">Capital</div>
    <div class="value"><?= showMoneyOrNA($societe['capital'] ?? null) ?></div>

    <div class="label">Durée de vie (années)</div>
    <div class="value"><?= showOrNA($societe['duree_vie'] ?? null) ?></div>

    <div class="label">Objet social</div>
    <div class="value"><?= showOrNA($societe['objet_social'] ?? null) ?></div>

    <div class="label">État</div>
    <div class="value"><?= showOrNA($societe['etat'] ?? null) ?></div>
  </div>

  <div class="actions">
    <?php if (!$isDissous): ?>
      <a class="btn btn-primary" href="index.php?action=modifier_societe&id=<?= $idSoc ?>">
        Mettre à jour les informations
      </a>
    <?php endif; ?>

    <a class="btn btn-light" href="index.php?action=mes_societes">Retour à mes sociétés</a>

    <?php if (!$isDissous): ?>
      <!-- Bouton dissoudre (rouge) -->
      <button type="button" class="danger-pill" id="btnDissoudre" title="Dissoudre">
        <span class="white-bar"></span>
      </button>
    <?php else: ?>
      <!-- Bouton réactiver (vert) -->
      <button type="button" class="success-pill" id="btnReactiver" title="Réactiver">
        <span class="white-bar"></span>
      </button>
    <?php endif; ?>
  </div>
</div>

<!-- Modale -->
<div id="modalRoot" class="modal-root"></div>

<?php if (!$isDissous): ?>
  <div class="actionnaires-section">
    <h3>Actionnaires</h3>

    <div class="filter-row">
      <label for="filtreRole">Filtrer par rôle :</label>
      <select id="filtreRole">
        <option value="all">Tout</option>
        <?php foreach ($roles as $r): ?>
          <option value="<?= (int)$r['id'] ?>">
            <?= htmlspecialchars($r['nom_role_actionnaires']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="actionnaires-grid" id="actionnairesList">
      <?php if (empty($actionnaires)): ?>
        <p>Aucun actionnaire enregistré pour cette société.</p>
      <?php else: ?>
        <?php foreach ($actionnaires as $a): ?>
<div class="actionnaire-card" data-roleid="<?= (int)$a['roleActionnaire_id'] ?>">
  <p><strong>Nom complet :</strong> <?= htmlspecialchars($a['nom']) ?></p>
  <p><strong>Rôle :</strong> <?= htmlspecialchars($a['role_nom']) ?></p>


<a href="index.php?action=apports&societe_id=<?= $societe['id'] ?>&actionnaire_id=<?= $a['id'] ?>" class="btn btn-primary">
    À propos
</a>


</div>





        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <div class="add-actionnaire">
<a href="index.php?action=new_actionnaire&societe_id=<?= $idSoc ?>" class="btn-add">
  + Ajouter un nouvel Actionnaire
</a>


    </div>
  </div>
<?php else: ?>
  <div class="actionnaires-section">
    <h3>Actionnaires</h3>
    <div class="actionnaires-grid">
      <?php if (empty($actionnaires)): ?>
        <p>Aucun actionnaire enregistré.</p>
      <?php else: ?>
        <?php foreach ($actionnaires as $a): ?>
          <div class="actionnaire-card">
            <p><strong>Nom complet :</strong> <?= htmlspecialchars($a['nom']) ?></p>
            <p><strong>Rôle :</strong> <?= htmlspecialchars($a['role_nom']) ?></p>
            <a class="btn-apropos" href="informationActionnaire.php?id=<?= (int)$a['id'] ?>">À propos</a>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
    <div class="add-actionnaire disabled">
      <button class="btn-add-disabled" disabled>+ Ajouter un nouvel Actionnaire</button>
    </div>
  </div>
<?php endif; ?>

<a href="index.php?action=reunion&societe_id=<?= $societe['id'] ?>">📅 Gérer les réunions</a>




<script>
(function(){
  const societeId = <?= json_encode($idSoc) ?>;
  const isDissous = <?= json_encode($isDissous) ?>;
  const modalRoot = document.getElementById('modalRoot');

  // Config “mini pages” (textes courts)
  const MODALS = {
    dissoudre: {
      title: "Dissoudre",
      sub: "Confirmez-vous la dissolution ? La société restera visible mais inactive.",
      causes: [
        "Arrêt d’activité", "Conflit associés", "Fusion/Absorption",
        "Objet atteint", "Pertes durables", "Choix stratégique"
      ],
      confirmText: "Confirmer",
      confirmColor: "red"
    },
    reactiver: {
      title: "Réactivation",
      sub: "Réactiver cette société ? Elle redeviendra active sur le site.",
      confirmText: "Confirmer",
      confirmColor: "green"
    },
    reactiver_ok: {
      title: "Réactivation validée !",
      sub: "Besoin d’autres changements ? Accédez à la mise à jour des informations.",
      nextText: "Suivant"
    }
  };

  function closeModal(){ modalRoot.style.display='none'; modalRoot.innerHTML=''; }

  function renderModal(config, withChips=false, afterConfirm=null) {
    const card = document.createElement('div');
    card.className = 'modal-card';

    const h = document.createElement('h3'); h.className='modal-title'; h.textContent = config.title;
    const p = document.createElement('p'); p.className='modal-sub'; p.textContent = config.sub;
    card.appendChild(h); card.appendChild(p);

    let selected = null;

    if (withChips && Array.isArray(config.causes)) {
      const wrap = document.createElement('div'); wrap.className='chips';
      config.causes.forEach(cause => {
        const c = document.createElement('div');
        c.className = 'chip';
        c.textContent = cause;
        c.addEventListener('click', () => {
          wrap.querySelectorAll('.chip').forEach(x => x.classList.remove('active'));
          c.classList.add('active');
          selected = cause;
        });
        wrap.appendChild(c);
      });
      card.appendChild(wrap);
    }

    const actions = document.createElement('div'); actions.className='modal-actions';
    const cancel = document.createElement('button'); cancel.className='btn btn-ghost'; cancel.textContent='Annuler';
    cancel.onclick = closeModal;

    const confirm = document.createElement('button');
    confirm.className = (config.confirmColor === 'red') ? 'btn btn-red' : 'btn btn-green';
    confirm.textContent = config.confirmText;

    confirm.onclick = () => { if (afterConfirm) afterConfirm(selected); };

    actions.appendChild(cancel); actions.appendChild(confirm);
    card.appendChild(actions);

    modalRoot.innerHTML = ''; modalRoot.appendChild(card); modalRoot.style.display = 'flex';
  }

  // Dissoudre -> POST classique (redirigé par le serveur)
  const btnD = document.getElementById('btnDissoudre');
  if (btnD) {
    btnD.addEventListener('click', () => {
      renderModal(MODALS.dissoudre, true, (selected) => {
        // Soumission par formulaire (simple et compatible)
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'index.php?action=societe_dissoudre';
        const i1 = document.createElement('input'); i1.type='hidden'; i1.name='id'; i1.value=societeId;
        const i2 = document.createElement('input'); i2.type='hidden'; i2.name='cause'; i2.value= selected || '';
        form.appendChild(i1); form.appendChild(i2);
        document.body.appendChild(form);
        form.submit();
      });
    });
  }

  // Réactiver -> POST via fetch puis 2e mini page “validée”
  const btnR = document.getElementById('btnReactiver');
  if (btnR) {
    btnR.addEventListener('click', () => {
      renderModal(MODALS.reactiver, false, () => {
        // On tente un POST AJAX; si ça échoue, fallback formulaire
        fetch('index.php?action=societe_reactiver', {
          method: 'POST',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: new URLSearchParams({ id: societeId, ajax: '1' })
        }).then(() => {
          // Deuxième mini page
          modalRoot.style.display='flex';
          modalRoot.innerHTML = '';
          const card = document.createElement('div'); card.className='modal-card';
          card.innerHTML = `
            <h3 class="modal-title">${MODALS.reactiver_ok.title}</h3>
            <p class="modal-sub">${MODALS.reactiver_ok.sub}</p>
            <div class="modal-actions">
              <a class="btn btn-ghost" href="USER_modify_societe.php?id=${societeId}">Modifier les infos</a>
              <a class="btn btn-green" href="index.php?action=dashboard_societe&id=${societeId}">${MODALS.reactiver_ok.nextText}</a>
            </div>`;
          modalRoot.appendChild(card);
        }).catch(() => {
          // Fallback formulaire
          const form = document.createElement('form');
          form.method = 'POST';
          form.action = 'index.php?action=societe_reactiver';
          const i1 = document.createElement('input'); i1.type='hidden'; i1.name='id'; i1.value=societeId;
          form.appendChild(i1);
          document.body.appendChild(form);
          form.submit();
        });
      });
    });
  }

  // Fermeture modale si on clique en dehors de la carte
  modalRoot.addEventListener('click', (e)=>{ if(e.target === modalRoot) closeModal(); });
})();
</script>

<script>
document.getElementById('filtreRole')?.addEventListener('change', e => {
  const selected = e.target.value;
  const cards = document.querySelectorAll('.actionnaire-card');
  cards.forEach(card => {
    const roleId = card.dataset.roleid;
    card.style.display = (selected === 'all' || roleId === selected) ? 'block' : 'none';
  });
});
</script>


</body>
</html>
