
<div class="container mt-4">
    <h5>Ma société : <?= htmlspecialchars($infos['societe_nom']) ?></h5>
    <h5>Nom complet : <?= htmlspecialchars($infos['actionnaire_nom']) ?></h5>
    <h5>Rôle : <?= htmlspecialchars($infos['role_nom']) ?></h5>

    <hr>

    <h3>List Apports</h3>

    <!-- Filtre -->
    <form method="get" class="mb-3">
        <input type="hidden" name="action" value="apports">
        <input type="hidden" name="societe_id" value="<?= htmlspecialchars($_GET['societe_id']) ?>">
        <input type="hidden" name="actionnaire_id" value="<?= htmlspecialchars($_GET['actionnaire_id']) ?>">
        
        <label>Filtrer par Type apport :</label>
        <select name="filter_type" onchange="this.form.submit()">
            <option value="all" <?= ($_GET['filter_type'] ?? '') == "all" ? 'selected' : '' ?>>Tout</option>
            <?php foreach($types as $t): ?>
                <option value="<?= $t['id'] ?>" <?= (isset($_GET['filter_type']) && $_GET['filter_type'] == $t['id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($t['nom']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>

    <!-- Liste des apports -->
    <div class="row">
        <?php if (count($apports) > 0): ?>
            <?php foreach($apports as $ap): ?>
                <div class="col-md-4">
                    <div class="card bg-primary text-white mb-3 p-3">
                        <strong>TYPE D’APPORT :</strong> <?= htmlspecialchars($ap['type_apport']) ?><br>
                        <strong>Description :</strong> <?= nl2br(htmlspecialchars($ap['description'])) ?><br>
                        <strong>Montant :</strong> <?= $ap['montant'] !== null ? number_format($ap['montant'], 2) : '' ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Aucun apport trouvé.</p>
        <?php endif; ?>
    </div>

<a href="index.php?action=new_apport&societe_id=<?= $_GET['societe_id'] ?>&actionnaire_id=<?= $_GET['actionnaire_id'] ?>">+ Nouvel apport</a>

</div>
