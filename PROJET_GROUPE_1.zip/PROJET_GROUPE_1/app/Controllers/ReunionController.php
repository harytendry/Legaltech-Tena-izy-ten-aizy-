<?php
require_once 'app/Models/Reunion.php';
require_once __DIR__ . '/../Libraries/fpdf.php';



class ReunionController {
    public function store($data) {
        $reunion = new Reunion();
        $id_reunion = $reunion->create($data);

        if (!empty($data['participants']['nom'])) {
            foreach ($data['participants']['nom'] as $key => $nom) {
                $post = $data['participants']['post'][$key];
                $reunion->addParticipant($id_reunion, $nom, $post);
            }
        }

        // Redirection vers la page réunion (affichage des réunions)
        header("Location: index.php?action=reunion&societe_id=" . $data['societe_id']);
        exit;
    }

    public function index($societe_id) {
    $reunion = new Reunion();
    $reunions = $reunion->getBySociete($societe_id);

    require 'app/Views/Reunion.php';
}

public function fairePv($id_reunion) {
    $reunion = new Reunion();
    $info = $reunion->getById($id_reunion); // réunion + participants
    require 'app/Views/fairePvReunion.php';
}

public function savePv($data) {
    $reunion = new Reunion();

    // 1. Insertion des décisions
    if (!empty($data['decisions'])) {
        foreach ($data['decisions'] as $decision) {
            if (trim($decision) !== '') {
                $reunion->addDecision($data['id_reunion'], $decision);
            }
        }
    }

    // 2. Mettre absent les participants cochés
    if (!empty($data['absents'])) {
        foreach ($data['absents'] as $id_participant) {
            $reunion->markAbsent($id_participant);
        }
    }

    // 3. Marquer la réunion comme déjà passée
    $reunion->markAsDone($data['id_reunion']);

    // Retour
    header("Location: index.php?action=reunion&societe_id=" . $data['societe_id']);
    exit;
}
public function voirPv($id_reunion) {
    require_once 'app/Libraries/fpdf.php';
    $reunion = new Reunion();
    $info = $reunion->getById($id_reunion); // réunion + participants
    $decisions = $reunion->getDecisions($id_reunion);

    // On sépare les présents et absents
    $presents = array_filter($info['participants'], fn($p) => $p['present'] == 1);
    $absents  = array_filter($info['participants'], fn($p) => $p['present'] == 0);

    $pdf = new FPDF();
    $pdf->AddPage();

    // Titre
    $pdf->SetFont('Arial','B',16);
    $pdf->Cell(0,10, utf8_decode($info['nom_societe']." : Procès verbal du ".$info['nom_reunion']), 0,1,'C');
    $pdf->Ln(5);

    // Infos réunion
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(0,8, utf8_decode("Date : ".$info['date']."  Heure : ".$info['heure']),0,1);
    $pdf->Cell(0,8, utf8_decode("Lieu : ".$info['lieu']),0,1);
    $pdf->Cell(0,8, utf8_decode("Objet : ".$info['objet']),0,1);
    $pdf->Ln(5);

    // Décisions
    $pdf->SetFont('Arial','B',13);
    $pdf->Cell(0,8, utf8_decode("Décisions prises :"),0,1);
    $pdf->SetFont('Arial','',12);
    if (!empty($decisions)) {
        foreach ($decisions as $d) {
            $pdf->MultiCell(0,8,"- ".utf8_decode($d['description']));
        }
    } else {
        $pdf->Cell(0,8,"Aucune décision enregistrée.",0,1);
    }
    $pdf->Ln(5);

    // Participants présents
    $pdf->SetFont('Arial','B',13);
    $pdf->Cell(0,8, utf8_decode("Participants présents :"),0,1);
    $pdf->SetFont('Arial','',12);
    if (!empty($presents)) {
        foreach ($presents as $p) {
            $pdf->Cell(0,8, utf8_decode("- ".$p['nom']." (".$p['post'].")"),0,1);
        }
    } else {
        $pdf->Cell(0,8,"Aucun présent.",0,1);
    }
    $pdf->Ln(5);

    // Participants absents
    $pdf->SetFont('Arial','B',13);
    $pdf->Cell(0,8, utf8_decode("Participants absents :"),0,1);
    $pdf->SetFont('Arial','',12);
    if (!empty($absents)) {
        foreach ($absents as $a) {
            $pdf->Cell(0,8, utf8_decode("- ".$a['nom']." (".$a['post'].")"),0,1);
        }
    } else {
        $pdf->Cell(0,8,"Aucun absent.",0,1);
    }

    // Téléchargement
    $filename = "Reunion_PV_".str_replace(" ","_",$info['nom_societe']).".pdf";
    $pdf->Output('D', $filename);
}


}
