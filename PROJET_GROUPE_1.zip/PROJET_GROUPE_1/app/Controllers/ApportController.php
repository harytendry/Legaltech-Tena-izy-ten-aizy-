<?php
require_once __DIR__ . '/../Core/Database.php';
require_once 'app/Models/Apport.php';


class ApportController {

    public function showApports() {
        $db = Database::getConnection();

        // Récupération des paramètres URL
        $societe_id = $_GET['societe_id'] ?? null;
        $actionnaire_id = $_GET['actionnaire_id'] ?? null;
        $filter_type = $_GET['filter_type'] ?? "all";

        if (!$societe_id || !$actionnaire_id) {
            die("Erreur : paramètres manquants.");
        }

        // Infos société + actionnaire + rôle
        $stmt = $db->prepare("
            SELECT s.nom AS societe_nom, a.nom AS actionnaire_nom, r.nom_role_actionnaires AS role_nom
            FROM actionnaires a
            JOIN societes s ON a.societe_id = s.id
            JOIN role_actionnaires r ON a.roleActionnaire_id = r.id
            WHERE a.id = ?
        ");
        $stmt->execute([$actionnaire_id]);
        $infos = $stmt->fetch(PDO::FETCH_ASSOC);

        // Liste des types d’apports (pour le filtre)
        $types = $db->query("SELECT id, nom FROM type_apports")->fetchAll(PDO::FETCH_ASSOC);

        // Requête apports
        $sql = "SELECT ap.id, ta.nom AS type_apport, ap.description, ap.montant 
                FROM apports ap
                JOIN type_apports ta ON ap.type_apport_id = ta.id
                WHERE ap.societe_id = ? AND ap.actionnaire_id = ?";
        
        $params = [$societe_id, $actionnaire_id];

        if ($filter_type !== "all") {
            $sql .= " AND ap.type_apport_id = ?";
            $params[] = $filter_type;
        }

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $apports = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Appel de la vue
        include __DIR__ . '/../Views/informationUser_apport.php';
    }
        public function store($data) {
        $apport = new Apport();
        $apport->create($data);

        // Après insertion → retour sur la page des apports
header("Location: index.php?action=apports&societe_id=" . $data['societe_id'] . "&actionnaire_id=" . $data['actionnaire_id']);
exit;

    }

}
