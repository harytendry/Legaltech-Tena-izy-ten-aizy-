<?php
require_once 'app/models/Societe.php';

class SocieteController {

    public function index() {
        if (session_status() === PHP_SESSION_NONE) { session_start(); }
        if (!isset($_SESSION['user'])) { 
            header('Location: index.php?action=login'); 
            exit; 
        }

        $user = $_SESSION['user'];
        $societes = Societe::getByUserId($user['id']);
        include 'app/views/MesSocietes.php';  
    }
public function inscription() {
    if (session_status() === PHP_SESSION_NONE) { session_start(); }
    if (!isset($_SESSION['user'])) { header('Location: index.php?action=login'); exit; }

    $types = Societe::getTypes();
    $errors = [];
    $popupMessage = null;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $user_id = $_SESSION['user']['id'];
        $type_societe_id = $_POST['type_societe_id'] ?? null;
        $nom = trim($_POST['nom'] ?? '');
        $siege = trim($_POST['siege'] ?? '');
        $date_creation = $_POST['date_creation'] ?? '';
        $capital = $_POST['capital'] ?? '0';
        $duree_vie = $_POST['duree_vie'] ?? '';
        $objet_social = trim($_POST['objet_social'] ?? '');

        if (!$type_societe_id) $errors[] = "Veuillez choisir un type de société.";
        if ($nom === '') $errors[] = "Le nom est obligatoire.";

        // 🔐 Validation capital_min
        if ($type_societe_id) {
            $req = Societe::getCapitalRequirement($type_societe_id);
            if ($req) {
                $typeNom = $req['type_nom'];
                $min = $req['capital_min']; // peut être NULL
                $capitalFloat = (float)$capital;
                $minFloat = ($min === null) ? 0.0 : (float)$min;

                if ($capitalFloat < $minFloat) {
                    // Message crédible pour le popup
                    $fmtCapital = number_format($capitalFloat, 0, ',', ' ');
                    $fmtMin = number_format($minFloat, 0, ',', ' ');
                    $popupMessage = "Pour le type « $typeNom », le capital social minimum requis est de $fmtMin Ar. Votre saisie ($fmtCapital Ar) est insuffisante. Merci d’ajuster le montant afin de respecter les exigences légales.";
                    // On NE crée pas, on reste sur la page
                }
            }
        }

        if (empty($errors) && !$popupMessage) {
            $ok = Societe::create(
                $user_id,
                $type_societe_id,
                $nom,
                $siege,
                $date_creation,
                $capital,
                $duree_vie,
                $objet_social
            );
            if ($ok) {
                header('Location: index.php?action=mes_societes');
                exit;
            } else {
                $errors[] = "Échec de l’enregistrement. Réessayez.";
            }
        }
    }

    // transmettre $popupMessage à la vue
    include 'app/views/InscriptionSociete.php';
}


public function dashboardSociete() {
    if (session_status() === PHP_SESSION_NONE) { session_start(); }
    if (!isset($_SESSION['user'])) { header('Location: index.php?action=login'); exit; }

    $user = $_SESSION['user'];
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($id <= 0) { header('Location: index.php?action=mes_societes'); exit; }

    $societe = Societe::getFullById($id, $user['id']);
    if (!$societe) { header('Location: index.php?action=mes_societes'); exit; }

    // 🔹 Charger actionnaires & rôles
    $actionnaires = Societe::getActionnairesBySociete($id);
    $roles = Societe::getAllRolesActionnaires();

    include 'app/views/dashboard_societe.php';
}


public function dissoudre() {
    if (session_status() === PHP_SESSION_NONE) { session_start(); }
    if (!isset($_SESSION['user'])) { header('Location: index.php?action=login'); exit; }

    $user_id = $_SESSION['user']['id'];
    $id = (int)($_POST['id'] ?? 0);
    // (optionnel) $cause = trim($_POST['cause'] ?? '');

    if ($id > 0 && Societe::updateEtat($id, $user_id, 'dissous')) {
        header("Location: index.php?action=dashboard_societe&id={$id}");
    } else {
        header("Location: index.php?action=mes_societes");
    }
    exit;
}

public function reactiver() {
    if (session_status() === PHP_SESSION_NONE) { session_start(); }
    if (!isset($_SESSION['user'])) { header('Location: index.php?action=login'); exit; }

    $user_id = $_SESSION['user']['id'];
    $id = (int)($_POST['id'] ?? 0);

    if ($id > 0 && Societe::updateEtat($id, $user_id, 'actif')) {
        header("Location: index.php?action=dashboard_societe&id={$id}");
    } else {
        header("Location: index.php?action=mes_societes");
    }
    exit;
}

public function modifier() {
    if (session_status() === PHP_SESSION_NONE) { session_start(); }
    if (!isset($_SESSION['user'])) { header('Location: index.php?action=login'); exit; }

    $user = $_SESSION['user'];
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($id <= 0) { header('Location: index.php?action=mes_societes'); exit; }

    // Récupération de la société (sécurité: appartient bien à l'utilisateur)
    $societe = Societe::getFullById($id, $user['id']);
    if (!$societe) { header('Location: index.php?action=mes_societes'); exit; }

    $types = Societe::getTypes();
    $errors = [];
    $popupMessage = null;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $type_societe_id = $_POST['type_societe_id'] ?? null;
        $nom = trim($_POST['nom'] ?? '');
        $siege = trim($_POST['siege'] ?? '');
        $capital = $_POST['capital'] ?? '';
        $duree_vie = $_POST['duree_vie'] ?? '';
        $objet_social = trim($_POST['objet_social'] ?? '');

        if (!$type_societe_id) $errors[] = "Veuillez choisir un type de société.";
        if ($nom === '') $errors[] = "Le nom est obligatoire.";

        // Vérif capital_min si possible
        if ($type_societe_id) {
            $req = Societe::getCapitalRequirement($type_societe_id);
            if ($req) {
                $min = $req['capital_min']; // peut être NULL
                $minFloat = ($min === null) ? 0.0 : (float)$min;
                $capitalFloat = ($capital === '' || $capital === null) ? 0.0 : (float)$capital;

                if ($capitalFloat < $minFloat) {
                    $fmtMin = number_format($minFloat, 0, ',', ' ');
                    $fmtCapital = number_format($capitalFloat, 0, ',', ' ');
                    $errors[] = "Capital minimum requis : {$fmtMin} Ar (saisi : {$fmtCapital} Ar).";
                }
            }
        }

        if (empty($errors)) {
            $ok = Societe::updateFields(
                $id, $user['id'], $type_societe_id, $nom, $siege, $capital, $duree_vie, $objet_social
            );
            if ($ok) {
                header("Location: index.php?action=dashboard_societe&id={$id}");
                exit;
            } else {
                $errors[] = "Échec de la mise à jour. Réessayez.";
            }
        }

        // Si erreurs → on garde les valeurs postées
        $societe['type_societe_id'] = (int)$type_societe_id;
        $societe['nom'] = $nom;
        $societe['siege'] = $siege;
        $societe['capital'] = $capital;
        $societe['duree_vie'] = $duree_vie;
        $societe['objet_social'] = $objet_social;
    }

    // Vue
    include 'app/views/USER_modify_societe.php';
}


public function newActionnaire() {
    if (session_status() === PHP_SESSION_NONE) { session_start(); }
    if (!isset($_SESSION['user'])) { header('Location: index.php?action=login'); exit; }

    $user = $_SESSION['user'];
    $societe_id = isset($_GET['societe_id']) ? (int)$_GET['societe_id'] : 0;
    if ($societe_id <= 0) { header('Location: index.php?action=mes_societes'); exit; }

    // Vérifier ownership + récupérer état
    $societe = Societe::getFullById($societe_id, $user['id']);
    if (!$societe) { header('Location: index.php?action=mes_societes'); exit; }

    // Si dissous, on interdit côté serveur aussi
    if ($societe['etat'] === 'dissous') {
        header('Location: index.php?action=dashboard_societe&id=' . $societe_id);
        exit;
    }

    $roles = Societe::getAllRolesActionnaires();
    $errors = [];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nom = trim($_POST['nom'] ?? '');
        $roleActionnaire_id = (int)($_POST['roleActionnaire_id'] ?? 0);

        if ($nom === '') $errors[] = "Le nom complet est obligatoire.";
        if ($roleActionnaire_id <= 0) $errors[] = "Veuillez choisir un rôle.";

        if (empty($errors)) {
            $ok = Societe::addActionnaire($societe_id, $nom, $roleActionnaire_id);
            if ($ok) {
                header('Location: index.php?action=dashboard_societe&id=' . $societe_id);
                exit;
            } else {
                $errors[] = "Échec de l’enregistrement. Réessayez.";
            }
        }
    }

    // Vue
    include 'app/views/NewActionnaires.php';
}


}
