<?php
require_once 'app/models/User.php';

class UserController {
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom = $_POST['nom'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            
            if (User::register($nom, $email, $password)) {
                header('Location: index.php?action=login');
            } else {
                echo "Erreur lors de l'inscription.";
            }
        } else {
            include 'app/views/register.php';
        }
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'];
            $password = $_POST['password'];
            $user = User::login($email, $password);
            if ($user) {
                session_start();
                $_SESSION['user'] = $user;
                // APRES
                header('Location: index.php?action=mes_societes');

            } else {
                echo "Email ou mot de passe incorrect.";
            }
        } else {
            include 'app/views/login.php';
        }
    }

    // public function dashboard() {
    //     session_start();
    //     if (!isset($_SESSION['user'])) {
    //         header('Location: index.php?action=login');
    //         exit;
    //     }
    //     include 'app/views/dashboard.php';
    // }
}
?>
