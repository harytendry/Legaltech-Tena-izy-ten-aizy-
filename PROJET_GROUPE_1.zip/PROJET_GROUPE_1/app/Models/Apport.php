<?php
require_once 'app/Core/Database.php';

class Apport {
    private $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    /**
     * Insérer un nouvel apport
     */
    public function create($data) {
        $sql = "INSERT INTO apports (societe_id, actionnaire_id, type_apport_id, montant, description) 
                VALUES (:societe_id, :actionnaire_id, :type_apport_id, :montant, :description)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':societe_id'    => $data['societe_id'],
            ':actionnaire_id'=> $data['actionnaire_id'],
            ':type_apport_id'=> $data['type_apport_id'],
            ':montant'       => !empty($data['montant']) ? $data['montant'] : null,
            ':description'   => !empty($data['description']) ? $data['description'] : null,
        ]);
    }

    /**
     * Récupérer tous les apports d’un actionnaire dans une société
     */
    public function getBySocieteAndActionnaire($societe_id, $actionnaire_id) {
        $sql = "SELECT a.*, t.nom AS type_apport
                FROM apports a
                JOIN type_apports t ON a.type_apport_id = t.id
                WHERE a.societe_id = :societe_id AND a.actionnaire_id = :actionnaire_id
                ORDER BY a.created_at DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':societe_id' => $societe_id,
            ':actionnaire_id' => $actionnaire_id
        ]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Supprimer un apport (optionnel)
     */
    public function delete($id) {
        $sql = "DELETE FROM apports WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
    }
}
