<?php
require_once 'app/core/Database.php';

class User {
    public static function register($nom, $email, $password) {
        $db = Database::getConnection();
        $stmt = $db->prepare("INSERT INTO users (nom, email, password, role) VALUES (?, ?, ?, 'user')");
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        return $stmt->execute([$nom, $email, $hashedPassword]);
    }

    public static function login($email, $password) {
        $db = Database::getConnection();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }
        return false;
    }
}
?>
