<?php
require_once 'app/Core/Database.php';

class Reunion {
    private $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    // Créer une réunion
    public function create($data) {
        $sql = "INSERT INTO reunions (societe_id, date, heure, lieu, objet, type_reunion_id) 
                VALUES (:societe_id, :date, :heure, :lieu, :objet, :type_reunion_id)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':societe_id' => $data['societe_id'],
            ':date' => $data['date'],
            ':heure' => $data['heure'],
            ':lieu' => $data['lieu'],
            ':objet' => $data['objet'],
            ':type_reunion_id' => $data['type_reunion_id']
        ]);
        return $this->db->lastInsertId();
    }

    // Ajouter un participant
    public function addParticipant($id_reunion, $nom, $post) {
        $sql = "INSERT INTO reunions_participant (id_reunions, nom, post) 
                VALUES (:id_reunions, :nom, :post)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':id_reunions' => $id_reunion,
            ':nom' => $nom,
            ':post' => $post
        ]);
    }

    public function getBySociete($societe_id) {
    $sql = "SELECT r.*, t.nom_reunion 
            FROM reunions r
            JOIN type_reunions t ON r.type_reunion_id = t.id
            WHERE r.societe_id = :sid
            ORDER BY r.date DESC, r.heure DESC";
    $stmt = $this->db->prepare($sql);
    $stmt->execute([':sid' => $societe_id]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Charger les participants
    $sqlP = "SELECT nom, post FROM reunions_participant WHERE id_reunions = :rid";
    $stmtP = $this->db->prepare($sqlP);
    foreach ($rows as &$r) {
        $stmtP->execute([':rid' => $r['id']]);
        $r['participants'] = $stmtP->fetchAll(PDO::FETCH_ASSOC);
    }
    return $rows;
}




public function addDecision($id_reunion, $description) {
    $sql = "INSERT INTO reunions_decision (id_reunions, description)
            VALUES (:id, :desc)";
    $stmt = $this->db->prepare($sql);
    $stmt->execute([
        ':id' => $id_reunion,
        ':desc' => $description
    ]);
}

public function markAbsent($id_participant) {
    $sql = "UPDATE reunions_participant SET present = FALSE WHERE id = :id";
    $stmt = $this->db->prepare($sql);
    $stmt->execute([':id' => $id_participant]);
}

public function markAsDone($id_reunion) {
    $sql = "UPDATE reunions SET deja_passe = TRUE WHERE id = :id";
    $stmt = $this->db->prepare($sql);
    $stmt->execute([':id' => $id_reunion]);
}


public function getDecisions($id_reunion) {
    $sql = "SELECT * FROM reunions_decision WHERE id_reunions = :id";
    $stmt = $this->db->prepare($sql);
    $stmt->execute([':id' => $id_reunion]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}




public function getById($id) {
    $sql = "SELECT r.*, t.nom_reunion, s.nom AS nom_societe
            FROM reunions r
            JOIN type_reunions t ON r.type_reunion_id = t.id
            JOIN societes s ON r.societe_id = s.id
            WHERE r.id = :id";
    $stmt = $this->db->prepare($sql);
    $stmt->execute([':id' => $id]);
    $reunion = $stmt->fetch(PDO::FETCH_ASSOC);

    // Charger participants
    $sqlP = "SELECT * FROM reunions_participant WHERE id_reunions = :id";
    $stmtP = $this->db->prepare($sqlP);
    $stmtP->execute([':id' => $id]);
    $reunion['participants'] = $stmtP->fetchAll(PDO::FETCH_ASSOC);

    return $reunion;
}


}
