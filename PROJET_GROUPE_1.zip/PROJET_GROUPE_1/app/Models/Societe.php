<?php
require_once 'app/core/Database.php';

class Societe {

public static function getByUserId($user_id) {
    $db = Database::getConnection();
    $stmt = $db->prepare("
        SELECT id, nom, etat
        FROM societes
        WHERE user_id = ?
        ORDER BY created_at DESC
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
public static function updateEtat($societe_id, $user_id, $nouvel_etat) {
    $db = Database::getConnection();
    $stmt = $db->prepare("UPDATE societes SET etat = ? WHERE id = ? AND user_id = ?");
    return $stmt->execute([$nouvel_etat, $societe_id, $user_id]);
}


    public static function getTypes() {
        $db = Database::getConnection();
        $stmt = $db->query("SELECT id, nom FROM types_societe ORDER BY nom ASC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


        public static function getCapitalRequirement($type_societe_id) {
        $db = Database::getConnection();
        $sql = "SELECT ts.nom AS type_nom, cs.capital_min
                FROM types_societe ts
                JOIN conditions_societes cs ON cs.id = ts.conditions_societes_id
                WHERE ts.id = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute([$type_societe_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC); 
    }

   public static function create($user_id, $type_societe_id, $nom, $siege, $date_creation, $capital, $duree_vie, $objet_social) {
        $db = Database::getConnection();
        $sql = "INSERT INTO societes (user_id, type_societe_id, nom, siege, date_creation, capital, duree_vie, objet_social)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $db->prepare($sql);
        $capital = ($capital === '' || $capital === null) ? 0 : $capital;
        $date_creation = ($date_creation === '') ? null : $date_creation;
        $duree_vie = ($duree_vie === '' || $duree_vie === null) ? null : (int)$duree_vie;

        return $stmt->execute([
            $user_id,
            $type_societe_id,
            $nom,
            $siege,
            $date_creation,
            $capital,
            $duree_vie,
            $objet_social
        ]);
    }

public static function getFullById($societe_id, $user_id) {
    $db = Database::getConnection();
    $sql = "SELECT s.*, ts.nom AS type_societe_nom
            FROM societes s
            JOIN types_societe ts ON ts.id = s.type_societe_id
            WHERE s.id = ? AND s.user_id = ?";  // sécurité: appartient bien à l'utilisateur
    $stmt = $db->prepare($sql);
    $stmt->execute([$societe_id, $user_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}


public static function updateFields($id, $user_id, $type_societe_id, $nom, $siege, $capital, $duree_vie, $objet_social) {
        $db = Database::getConnection();

        $sql = "UPDATE societes 
                SET type_societe_id = ?, nom = ?, siege = ?, capital = ?, duree_vie = ?, objet_social = ?
                WHERE id = ? AND user_id = ?";
        $stmt = $db->prepare($sql);

        // normalisations
        $capital = ($capital === '' || $capital === null) ? null : (float)$capital;
        $duree_vie = ($duree_vie === '' || $duree_vie === null) ? null : (int)$duree_vie;

        return $stmt->execute([
            $type_societe_id,
            $nom,
            $siege,
            $capital,
            $duree_vie,
            $objet_social,
            $id,
            $user_id
        ]);
    }
public static function getActionnairesBySociete($societe_id) {
    $db = Database::getConnection();
    $sql = "SELECT a.id, a.nom, a.roleActionnaire_id, r.nom_role_actionnaires AS role_nom
            FROM actionnaires a
            JOIN role_actionnaires r ON r.id = a.roleActionnaire_id
            WHERE a.societe_id = ?
            ORDER BY a.created_at DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute([$societe_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


// Rôles pour la liste déroulante
public static function getAllRolesActionnaires() {
    $db = Database::getConnection();
    $stmt = $db->query("SELECT id, nom_role_actionnaires FROM role_actionnaires ORDER BY nom_role_actionnaires ASC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Insertion d'un actionnaire
public static function addActionnaire($societe_id, $nom, $roleActionnaire_id) {
    $db = Database::getConnection();
    $sql = "INSERT INTO actionnaires (societe_id, nom, roleActionnaire_id) VALUES (?, ?, ?)";
    $stmt = $db->prepare($sql);
    return $stmt->execute([$societe_id, $nom, $roleActionnaire_id]);
}

}
?>
