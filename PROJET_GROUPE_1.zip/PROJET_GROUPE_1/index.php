<?php

if (session_status() === PHP_SESSION_NONE) { session_start(); }

require_once 'config/config.php';
require_once 'app/controllers/UserController.php';
require_once 'app/controllers/SocieteController.php';
require_once 'app/Controllers/ApportController.php';

$action = $_GET['action'] ?? 'login';
$controller = new UserController();
$controller = new ApportController();

switch ($action) {
    case 'login':
        (new UserController())->login();
        break;
    case 'register':
        $controller->register();
        break;

    case 'mes_societes':
        $controller = new SocieteController();
        $controller->index();
        break;
    case 'inscription_societe':
        (new SocieteController())->inscription();
        break;
    case 'dashboard_societe':
        (new SocieteController())->dashboardSociete();
        break;
    case 'societe_dissoudre':
    (new SocieteController())->dissoudre();
    break;
    

case 'societe_reactiver':
    (new SocieteController())->reactiver();
    break;
case 'modifier_societe':
    (new SocieteController())->modifier();
    break;
case 'new_actionnaire':
    (new SocieteController())->newActionnaire();
    break;
case 'apports':
        $controller = new ApportController();
        $controller->showApports();
        break;
case 'new_apport':
    require 'app/Views/NewApport.php';
    break;


    
case 'save_apport':
    require_once 'app/Controllers/ApportController.php';
    $controller = new ApportController();
    $controller->store($_POST);
    break;

// case 'reunion':
//     require 'app/Views/Reunion.php';
//     break;



case 'save_reunion':
    require_once 'app/Controllers/ReunionController.php';
    $controller = new ReunionController();
    $controller->store($_POST);
    break;

case 'reunion':
    require_once 'app/Controllers/ReunionController.php';
    $controller = new ReunionController();
    $controller->index($_GET['societe_id']);
    break;

case 'faire_pv':
    require_once 'app/Controllers/ReunionController.php';
    $controller = new ReunionController();
    $controller->fairePv($_GET['id']); // id = réunion
    break;

case 'save_pv':
    require_once 'app/Controllers/ReunionController.php';
    $controller = new ReunionController();
    $controller->savePv($_POST);
    break;


case 'voir_pv':
    require_once 'app/Controllers/ReunionController.php';
    $controller = new ReunionController();
    $controller->voirPv($_GET['id']);
    break;



    default:
        // Si connecté → Mes Sociétés ; sinon → Login
        if (isset($_SESSION['user'])) {
            header('Location: index.php?action=mes_societes');
        } else {
            header('Location: index.php?action=login');
        }
        exit;
}
?>
