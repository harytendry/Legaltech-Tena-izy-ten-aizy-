<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'legaltech');
define('DB_USER', 'root');
define('DB_PASS', '');

define('BASE_URL', 'http://localhost/PROJET_GROUPE_1/');

?>
