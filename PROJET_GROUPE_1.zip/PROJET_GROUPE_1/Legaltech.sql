drop database legaltech;
create database legaltech;

use legaltech
-- ne pas creer
CREATE TABLE IF NOT EXISTS users (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','user') NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 
  CREATE TABLE IF NOT EXISTS conditions_societes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nb_min_associes INT NOT NULL,
    nb_max_associes INT DEFAULT NULL,
    condition_texte TEXT DEFAULT NULL, 
    capital_min DECIMAL(50,2) DEFAULT NULL 
  );


  -- 
  CREATE TABLE IF NOT EXISTS types_societe (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(120) NOT NULL UNIQUE,
    description TEXT DEFAULT NULL,
    conditions_societes_id BIGINT NOT NULL,  
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conditions_societes_id) REFERENCES conditions_societes(id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ne pas creer
CREATE TABLE IF NOT EXISTS societes (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  type_societe_id BIGINT NOT NULL,
  nom VARCHAR(190) NOT NULL,
  siege VARCHAR(255) DEFAULT NULL,
  date_creation DATE DEFAULT NULL,
  capital DECIMAL(50,2) DEFAULT NULL,
  duree_vie INT,
    objet_social VARCHAR(255), 
  etat ENUM('actif','dissous') NOT NULL DEFAULT 'actif',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (type_societe_id) REFERENCES types_societe(id) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 
CREATE TABLE IF NOT EXISTS role_actionnaires (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nom_role_actionnaires VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ne pas creer
CREATE TABLE IF NOT EXISTS actionnaires (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  societe_id BIGINT NOT NULL,
  nom VARCHAR(190) NOT NULL,
  roleActionnaire_id BIGINT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (societe_id) REFERENCES societes(id),
  FOREIGN KEY (roleActionnaire_id) REFERENCES role_actionnaires(id) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 
CREATE TABLE IF NOT EXISTS type_apports (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(50) NOT NULL
  -- ('argent','materiel','nature') ihany
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ne pas creer
CREATE TABLE IF NOT EXISTS apports (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  societe_id BIGINT NOT NULL,
  actionnaire_id BIGINT DEFAULT NULL,
  type_apport_id BIGINT NOT NULL,
  montant DECIMAL(50,2) DEFAULT NULL,
  description TEXT DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (societe_id) REFERENCES societes(id) ,
  FOREIGN KEY (actionnaire_id) REFERENCES actionnaires(id),
  FOREIGN KEY (type_apport_id) REFERENCES type_apports(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 
CREATE TABLE IF NOT EXISTS  categorie_recettes( -- categorie = type ihany 
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nom_categorie_recettes VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ne pas creer
CREATE TABLE IF NOT EXISTS recettes (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  societe_id BIGINT NOT NULL,
  date DATE NOT NULL,
  montant DECIMAL(50,2) DEFAULT NULL,
  sources VARCHAR(255) DEFAULT NULL, -- afaka anonyme 
  categorie_id BIGINT NOT NULL,
  description TEXT DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (societe_id) REFERENCES societes(id), 
  FOREIGN KEY (categorie_id) REFERENCES categorie_recettes(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 
CREATE TABLE IF NOT EXISTS  categorie_depenses( -- categorie = type 
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nom_categorie_depenses VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- ne pas creer
CREATE TABLE IF NOT EXISTS depenses ( 
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  societe_id BIGINT NOT NULL,
  destinataire VARCHAR(255) NOT NULL,  
  date DATE NOT NULL,
  montant DECIMAL(50,2) ,
  categorie_id BIGINT NOT NULL,
  description TEXT DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (societe_id) REFERENCES societes(id),
  FOREIGN KEY (categorie_id) REFERENCES categorie_depenses(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 
CREATE TABLE IF NOT EXISTS type_reunions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nom_reunion VARCHAR(100) NOT NULL 
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- ne pas creer
CREATE TABLE IF NOT EXISTS reunions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  societe_id BIGINT NOT NULL,
  date DATE NOT NULL,
  heure TIME NOT NULL,
  lieu VARCHAR(190) DEFAULT NULL,
  objet VARCHAR(255) NOT NULL,
  type_reunion_id BIGINT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deja_passe BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (societe_id) REFERENCES societes(id),
  FOREIGN KEY (type_reunion_id) REFERENCES type_reunions(id) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- ne pas creer
CREATE TABLE IF NOT EXISTS reunions_participant (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  id_reunions BIGINT NOT NULL,
  nom VARCHAR(255) NOT NULL,
  post VARCHAR(255) NOT NULL,
  present BOOLEAN DEFAULT TRUE, 
  FOREIGN KEY (id_reunions) REFERENCES reunions(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;




-- ne pas creer
CREATE TABLE IF NOT EXISTS reunions_decision (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  id_reunions BIGINT NOT NULL,
  description VARCHAR(255) NOT NULL,
  FOREIGN KEY (id_reunions) REFERENCES reunions(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- ne pas creer
CREATE TABLE IF NOT EXISTS pv_reunions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  id_reunions BIGINT NOT NULL ,
  FOREIGN KEY (id_reunions) REFERENCES reunions(id)
);












-- 
CREATE TABLE IF NOT EXISTS choix_des_convention (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(155) NOT NULL
);

-- 
CREATE TABLE IF NOT EXISTS types_convention (
  id BIGINT  AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(190) NOT NULL UNIQUE, 
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE IF NOT EXISTS lois (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    numero_loi VARCHAR(100) NOT NULL,
    intitule VARCHAR(255) NOT NULL,
    categorie VARCHAR(120) DEFAULT NULL,
    date_promulgation DATE DEFAULT NULL,
    resume TEXT DEFAULT NULL,
    conditions TEXT DEFAULT NULL,
    source VARCHAR(255) DEFAULT NULL,
    type_convention_id BIGINT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (type_convention_id) REFERENCES types_convention(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;





-- ne pas creer
CREATE TABLE IF NOT EXISTS conventions (
  id BIGINT  AUTO_INCREMENT PRIMARY KEY,
  societe_id BIGINT  NOT NULL,
  type_convention_id BIGINT  NOT NULL,
  objet_de_la_convention VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  date_debut DATE NOT NULL,
  date_fin DATE NOT NULL,
  choix_des_convention_id BIGINT NOT NULL,
  description LONGTEXT DEFAULT NULL,
  FOREIGN KEY (societe_id) REFERENCES societes(id), 
  FOREIGN KEY (type_convention_id) REFERENCES types_convention(id),
  FOREIGN KEY (choix_des_convention_id) REFERENCES choix_des_convention(id)  
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ne pas creer ( deja cree selon donnee dans figma )
CREATE TABLE IF NOT EXISTS type_conventions_attribution (
  id BIGINT  AUTO_INCREMENT PRIMARY KEY,
  nom_champ VARCHAR(255) NOT NULL,
  type_convention_id BIGINT NOT NULL, 
  Type_nom_champ VARCHAR(255) NOT NULL,
  FOREIGN KEY (type_convention_id) REFERENCES types_convention(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ne pas creer
CREATE TABLE IF NOT EXISTS type_conventions_valeur (
  id BIGINT  AUTO_INCREMENT PRIMARY KEY,
  type_conventions_attribution_id BIGINT NOT NULL,
  valeur VARCHAR(255) NOT NULL,
  FOREIGN KEY (type_conventions_attribution_id) REFERENCES type_conventions_attribution(id)
);







-- ne pas creer ( inerstion via admin interface )
CREATE TABLE IF NOT EXISTS jurisprudences (
  id BIGINT  AUTO_INCREMENT PRIMARY KEY,
  types_convention_id BIGINT NOT NULL,
  titre VARCHAR(100) NOT NULL,
  refference VARCHAR(155) NOT NULL,
  date_de_creation DATE NOT NULL,
  juridiction VARCHAR(255) NOT NULL,
  resume VARCHAR(255) NOT NULL,
  lois_id BIGINT NOT NULL,
  source VARCHAR(255) NOT NULL,
    FOREIGN KEY (types_convention_id) REFERENCES types_convention(id),
    FOREIGN KEY (lois_id) REFERENCES lois(id)
);

 


